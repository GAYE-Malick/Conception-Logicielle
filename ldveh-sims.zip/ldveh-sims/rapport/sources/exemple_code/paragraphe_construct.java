public Para(Integer id, String text) {

	this.id = id;
	this.text = text;
	this.choix = new HashMap<Integer, Para>();
	this.words = new ArrayList<String>();
	this.choicesList = new ArrayList<Para>();
	this.posX = 0;
	this.posY = 0;
	}

