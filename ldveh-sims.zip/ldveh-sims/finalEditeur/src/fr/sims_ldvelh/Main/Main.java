package fr.sims_ldvelh.Main;

import java.util.Scanner;

import fr.sims_ldvelh.Model.Main_Model;
import fr.sims_ldvelh.View.Main_View;

/**
 * La classe Main principale.<br>
 * Elle ne possède que la méthode main.
 * 
 * @author Ibrahima Sory Bah, Malick Sarr Gaye, Ahouefa Zounon, Steven Martin
 */
public class Main { 

	/**
	 * La méthode principale
	 * 
	 * @param args
	 * 
	 * @exception Exception déclanchée lorsque l'on arrive pas à charger les classes Main des autres packages.
	 */
	public static void main(String[] args) { //throws Exception {
		
		Scanner sc = new Scanner(System.in);
		Integer x = null;
		
		 //Introduction
		System.out.println("Bienvenue dans l'éditeur SIMS : un éditeur de livre dont vous êtes le héros.");
		System.out.println("Nous sommes ravis de vous accueillir! Nous vous prions de suivre toutes les consignes qui vous serons communiquées au fur et à mesure de votre avancée.");
		System.out.println("L'éditeur est disponible en deux modes: le mode console et le mode graphique. ");
		
		try
		{
			do
			{
				System.out.println("Si vous souhaitez le lancer en mode console, veuillez entrer 0 \nSi vous souhaitez le lancer en mode graphique, veuillez entrer 1");
				
				x = sc.nextInt();
				
				if(x!=0 && x!=1)
				{
					sc.nextLine();
					System.out.println("Veuillez saisir un chiffre : 0 ou 1");				
				}
				
			} while(x!=0 && x!=1);
		}
		
		catch(Exception e)
		{
			sc.nextLine();
			System.out.println("Vous avez entrez autre chose qu'un entier. Veuillez recommencer.");
			//e.printStackTrace();
		}
		
		if(x == 0)
		{
			try 
			{
				Main_Model.main(args); //Le mode console
				
				/*new Thread() {
			     public void run() {
			    	try 
			    	{
						Main_Model.main(args);
					} 
					
					catch (Exception e) {
						System.out.println("Impossible de faire l'exécution");
						e.printStackTrace();
					}
			     }
			   }.start();
			  */
			} 
			
			catch (Exception e) {
				System.out.println("Impossible de faire l'exécution");
				//e.printStackTrace();
			}
		}
		
		else
		{
			try 
			{
				Main_View.main(args); //Le mode graphique
				
				/*new Thread() {
			     public void run() {
			    	try 
			    	{
						Main_View.main(args);
					} 
					
					catch (Exception e) {
						System.out.println("Impossible de faire l'exécution");
						e.printStackTrace();
					}
			     }
			   }.start();
			  */
			} 
			
			catch (Exception e) {
				System.out.println("Impossible de faire l'exécution");
				//e.printStackTrace();
			}
		}
		
		sc.close();
	}

}
