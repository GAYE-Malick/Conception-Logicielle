package fr.sims_ldvelh.View;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import fr.sims_ldvelh.Controller.FirstEditorControl;
import fr.sims_ldvelh.Model.Para;

/**
 * La classe s'occupe de la présentation du panel de de création des paragraphes.<br>
 * 
 * Cette classe a pour attribut(s): 
 * <ul>
 * <li> Un JButton <b>createPara</b> qui est le bouton permettant de notifier le système que l'on a fini de créer un paragraphe.</li>
 * <li> Un CreateParagraph <b>cp</b> qui est le panel gérant la création d'un paragraphe. </li>
 * <li> Un ListParagraph <b>lp</b> qui est le panel gérant l'affichage de la liste des paragraphes créés. </li>
 * <li> Un ArrayList <b>listPara</b> de Para qui est la liste de tous les paragraphes crées. </li>
 * </ul>
 * 
 * Cette classe a pour méthode(s): 
 * <ul>
 * <li> Un JButton <b>getCreatePara</b> qui permet d'accéder au JButton "createPara" de la classe FirstEditor.</li>
 * <li> Un CreateParagraph <b>getCp</b> qui permet d'accéder au panel de création d'un paragraphe contenu dans la classe FirstEditor.</li>
 * <li> Un ListParagraph <b>getLp</b> qui permet d'accéder au panel de listage des paragraphes créés contenu dans la classe FirstEditor.</li>
 * <li> Un ArrayList <b>getListPara</b> de Para qui permet d'accéder à la liste de paragraphes finalement créés.</li>
 * </ul>
 * 
 * Veuillez noter que le constructeur n'est pas cité.<br>
 * 
 * @author Ibrahima Sory Bah, Malick Sarr Gaye, Ahouefa Zounon, Steven Martin
 */
public class FirstEditor extends JPanel {

	/**
	 * Attribut notifiant le système que l'on a fini de créer un paragraphe.
	 */
	private JButton createPara = new JButton("Créer paragraphe");
	
	/**
	 * Attribut JPanel gérant la création d'un paragraphe.
	 */
	private CreateParagraph cp;
	
	/**
	 * Attribut JPanel gérant l'affichage de la liste des paragraphes créés.
	 */
	private ListParagraph lp;

	/**
	 * Attribut représentant la liste de tous les paragraphes crées.
	 */
	private ArrayList<Para> listPara = new ArrayList<Para>();

	/**
	 * <b>Constructeur de la classe FirstEditor</b>
	 */
	public FirstEditor() {

		super();
		this.setBackground(Color.WHITE);

		JPanel leftSide = new JPanel();
		JScrollPane rightSide;

		leftSide.setLayout(new BorderLayout());

		this.cp = new CreateParagraph();
		this.createPara.addActionListener(new FirstEditorControl(this));

		leftSide.add(cp, BorderLayout.CENTER);
		leftSide.add(this.createPara, BorderLayout.SOUTH);

		this.lp = new ListParagraph();

		rightSide = new JScrollPane(this.lp);
		rightSide.setBorder(BorderFactory.createTitledBorder("<html> <h2> Liste des paragraphes </h2> </html>"));

		this.setLayout(new GridLayout(1, 2));

		this.add(leftSide);
		this.add(rightSide);

	}

//GETTERS ET SETTERS	
	
	/**
	 * Méthode permettant d'accéder au JButton "createPara" de la classe FirstEditor
	 * 
	 * @return Une référence sur le JButton createPara.
	 */
	public JButton getCreatePara() {
		return this.createPara;
	}

	/**
	 * Méthode permettant d'accéder au JPanel CreateParagraph "cp" de la classe FirstEditor.
	 * 
	 * @return Une référence sur le CreateParagraph cp.
	 */
	public CreateParagraph getCp() {
		return this.cp;
	}

	/**
	 * Méthode permettant d'accéder à la JList ListParagraph "lp" de la classe FirstEditor.
	 * 
	 * @return Une référence sur le ListParagraph lp.
	 */
	public ListParagraph getLp() {
		return this.lp;
	}

	/**
	 * Méthode permettant d'accéder à la liste de paragraphes de la classe FirstEditor.
	 * 
	 * @return Une référence sur la liste listPara.
	 */
	public ArrayList<Para> getListPara() {
		return this.listPara;
	}

}
