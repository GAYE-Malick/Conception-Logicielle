package fr.sims_ldvelh.View;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import fr.sims_ldvelh.Controller.SecondEditorControl;
import fr.sims_ldvelh.Model.Para;

/** 
 * La classe s'occupe de la présentation du graphe.<br>
 * 
 * Cette classe a pour attribut(s): 
 * <ul>
 * <li> Un SecondEditor <b>sE</b> </li>
 * <li> Un ArrayList <b>list</b> </li>
 * <li> Un JPopupMenu <b>menu</b> </li>
 * <li> Un JMenuItem <b>disp</b> </li>
 * <li> Un JMenuItem <b>editer</b> </li>
 * <li> Un JMenuItem <b>del</b> </li>
 * <li> Un JMenuItem <b>addC</b> </li>
 * <li> Un JMenuItem <b>remC</b> </li>
 * <li> Un JMenuItem <b>remCT</b> </li>
 * <li> Un JMenuItem <b>addW</b> </li>
 * <li> Un JMenuItem <b>remW</b> </li>
 * <li> Un JMenuItem <b>remWT</b> </li>
 * <li> Un DefaultListModel <b>model</b> de String</li>
 * <li> Un int <b>idSelectedItem</b>  </li>
 * <li> Un Para <b>para</b>  </li>
 * <li> Un DisplayParagraph <b>dp</b>  </li>
 * <li> Un EditParagraph <b>ep</b>  </li>
 * </ul>
 * 
 * Cette classe a pour méthode(s): 
 * <ul>
 * <li> Un SecondEditor <b>getsE</b> </li>
 * <li> Un ArrayList <b>getList</b> de Para. </li>
 * <li> Un JPopupMenu <b>getMenu</b> </li>
 * <li> Un JMenuItem <b>getDisp</b> </li>
 * <li> Un JMenuItem <b>getEditer</b> </li>
 * <li> Un JMenuItem <b>getDel</b> </li>
 * <li> Un JMenuItem <b>getDp</b> </li>
 * <li> Un JMenuItem <b>getAddC</b> </li>
 * <li> Un JMenuItem <b>getRemC</b> </li>
 * <li> Un JMenuItem <b>getRemCT</b> </li>
 * <li> Un JMenuItem <b>getAddW</b> </li>
 * <li> Un JMenuItem <b>getRemW</b> </li>
 * <li> Un JMenuItem <b>getRemWT</b> </li>
 * <li> Un DefaultListModel <b>getModel</b> </li>
 * <li> Un int <b>getIdSelectedItem</b> </li>
 * <li> Un Para <b>getPara</b> </li>
 * <li> Un EditParagraph <b>getEp</b> </li>
 * <li> Un void <b>setList</b> </li>
 * <li> Un void <b>setDp</b> </li>
 * </ul>
 * 
 * Veuillez noter que le constructeur n'est pas cité.<br>
 * 
 * @author Ibrahima Sory Bah, Malick Sarr Gaye, Ahouefa Zounon, Steven Martin
 */
public class DisplayListP extends JList<String> implements ListSelectionListener {

	/**
	 * Attribut représentant le SecondEditor auquel appartient l'élément DisPlayList.
	 */
	private SecondEditor sE;
	
	/**
	 * Attribut représentant la liste des paragraphes.
	 */
	private ArrayList<Para> list;
	
	/**
	 * Attribut représentant le menu qui s'affiche au clic droit sur un élément de la liste.
	 */
	private JPopupMenu menu = new JPopupMenu();
	
	/**
	 * Ensemble d'attributs représentants les différentes actions possibles sur le paragraphe sélectionné.
	 */
	private JMenuItem disp, editer, del, addC, remC, remCT, addW, remW, remWT;
	
	/**
	 * Attribut représentant le modèle que DisplayListP utilise pour afficher ses éléments.
	 */
	private DefaultListModel<String> model = new DefaultListModel<String>();

	/**
	 * Attribut représentant l'indice de l'élement sélectionné dans la liste.
	 */
	private int idSelectedItem;
	
	/**
	 * Attribut représentant le paragraphe correspondant à celui de la liste des paragraphes dont l'indice est égale à idSelectedItem.
	 */
	private Para para;
	
	/**
	 * Attribut représentant l'affichage d'un paragraphe.
	 */
	private DisplayParagraph dp;
	
	/**
	 * Attribut représentant l'édition d'un paragraphe.
	 */
	private EditParagraph ep;

	/**
	 * <b>Constructeur de la classe DisplayListP</b>
	 * 
	 * @param sE
	 * 		L'élément SecondEditor à passer à l'attribut sE de la classe DisplayListP.
	 */
	public DisplayListP(SecondEditor sE) {

		super();
		this.setBackground(Color.WHITE);

		this.sE = sE;
		this.list = this.sE.getListPara();

		// Le menu
		this.disp = new JMenuItem("Afficher");
		this.editer = new JMenuItem("Editer");
		this.del = new JMenuItem("Supprimer");
		this.addC = new JMenuItem("Ajouter un choix");
		this.remC = new JMenuItem("Retirer un choix");
		this.remCT = new JMenuItem("Retirer tous les choix");
		this.addW = new JMenuItem("Ajouter un pouvoir");
		this.remW = new JMenuItem("Retirer un pouvoir");
		this.remWT = new JMenuItem("Retirer tous les pouvoirs");

		this.menu.add(this.disp);
		this.menu.add(this.editer);
		this.menu.add(this.del);
		this.menu.add(this.addC);

		for (int i = 0; i < this.list.size(); i++) {

			this.model.addElement(
					this.list.get(i).getID() + " : " + this.list.get(i).getText().substring(0, 110) + "...");

		}

		this.setModel(this.model);
		this.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

		this.addListSelectionListener(this);
		SecondEditorControl dlpc = new SecondEditorControl(this.sE);
		this.disp.addActionListener(dlpc);
		this.editer.addActionListener(dlpc);
		this.del.addActionListener(dlpc);
		this.addC.addActionListener(dlpc);
		this.remC.addActionListener(dlpc);
		this.remCT.addActionListener(dlpc);
		this.addW.addActionListener(dlpc);
		this.remW.addActionListener(dlpc);
		this.remWT.addActionListener(dlpc);

	}

	/**
	 * Méthode héritée de l'interface ListSelectionListener.
	 * 
	 * @param e
	 * 		L'action de sélectionner un élément de la liste.
	 */
	@Override
	public void valueChanged(ListSelectionEvent e) {
		
		if (!e.getValueIsAdjusting()) {

			this.idSelectedItem = this.getSelectedIndex();
			this.para = this.list.get(this.idSelectedItem);
			this.dp = new DisplayParagraph(this.para);

			this.addMouseListener(new MouseAdapter() {

				// @Override
				public void mouseReleased(MouseEvent event) {
					if (!para.getChoicesList().isEmpty()) {
						menu.add(remC);
						menu.add(remCT);
					}

					menu.add(addW);

					if (!para.getWords().isEmpty()) {
						menu.add(remW);
						menu.add(remWT);
					}

					if ((event.getButton() == MouseEvent.BUTTON1) && (event.getClickCount() == 2)) {
						dp = new DisplayParagraph(para);
						sE.getRightSide().add(dp, BorderLayout.CENTER);
						sE.getRightSide().validate();
					}

					else if (event.getButton() == MouseEvent.BUTTON3) {
						menu.show(DisplayListP.this, event.getX(), event.getY());
					}
				}
			});
		}
	}

// GETTERS ET SETTERS

	/**
	 * Méthode permettant d'accéder au SecondEditor "sE" de la classe DisplayListP.
	 * 
	 * @return Une référence sur l'attribut sE.
	 */
	public SecondEditor getsE() {
		return this.sE;
	}

	/**
	 * Méthode permettant d'accéder à la liste de paragraphes "list" de la classe DisplayListP.
	 * 
	 * @return Une référence sur l'attribut list.
	 */
	public ArrayList<Para> getList() {
		return this.list;
	}

	/**
	 * Méthode permettant d'accéder au JPopupMenu "menu" de la classe DisplayListP.
	 * 
	 * @return Une référence sur l'attribut menu.
	 */
	public JPopupMenu getMenu() {
		return this.menu;
	}

	/**
	 * Méthode permettant d'accéder au JMenuItem "disp" de la classe DisplayListP.
	 * 
	 * @return Une référence sur l'attribut disp.
	 */
	public JMenuItem getDisp() {
		return this.disp;
	}

	/**
	 * Méthode permettant d'accéder au JMenuItem "editer" de la classe DisplayListP.
	 * 
	 * @return Une référence sur l'attribut editer.
	 */
	public JMenuItem getEditer() {
		return this.editer;
	}

	/**
	 * Méthode permettant d'accéder au JMenuItem "del" de la classe DisplayListP.
	 * 
	 * @return Une référence sur l'attribut del.
	 */
	public JMenuItem getDel() {
		return this.del;
	}

	/**
	 * Méthode permettant d'accéder au JMenuItem "dp" de la classe DisplayListP.
	 * 
	 * @return Une référence sur l'attribut dp.
	 */
	public DisplayParagraph getDp() {
		return this.dp;
	}

	/**
	 * Méthode permettant d'accéder au JMenuItem "addC" de la classe DisplayListP.
	 * 
	 * @return Une référence sur l'attribut addC.
	 */
	public JMenuItem getAddC() {
		return this.addC;
	}

	/**
	 * Méthode permettant d'accéder au JMenuItem "remC" de la classe DisplayListP.
	 * 
	 * @return Une référence sur l'attribut remC.
	 */
	public JMenuItem getRemC() {
		return this.remC;
	}

	/**
	 * Méthode permettant d'accéder au JMenuItem "remCT" de la classe DisplayListP.
	 * 
	 * @return Une référence sur l'attribut remCT.
	 */
	public JMenuItem getRemCT() {
		return this.remCT;
	}

	/**
	 * Méthode permettant d'accéder au JMenuItem "addW" de la classe DisplayListP.
	 * 
	 * @return Une référence sur l'attribut addW.
	 */
	public JMenuItem getAddW() {
		return this.addW;
	}

	/**
	 * Méthode permettant d'accéder au JMenuItem "remW" de la classe DisplayListP.
	 * 
	 * @return Une référence sur l'attribut remW.
	 */
	public JMenuItem getRemW() {
		return this.remW;
	}

	/**
	 * Méthode permettant d'accéder au JMenuItem "remWT" de la classe DisplayListP.
	 * 
	 * @return Une référence sur l'attribut remWT.
	 */
	public JMenuItem getRemWT() {
		return this.remWT;
	}

	/**
	 * Méthode permettant d'accéder au modèle "disp" de la classe DisplayListP.
	 * 
	 * @return Une référence sur l'attribut model.
	 */
	public DefaultListModel<String> getModel() {
		return this.model;
	}

	/**
	 * Méthode permettant d'accéder à l'entier "idSelectedItem" de la classe DisplayListP.
	 * 
	 * @return Une référence sur l'attribut idSelectedItem.
	 */
	public int getIdSelectedItem() {
		return this.idSelectedItem;
	}

	/**
	 * Méthode permettant d'accéder au paragraphe "para" de la classe DisplayListP.
	 * 
	 * @return Une référence sur l'attribut para.
	 */
	public Para getPara() {
		return this.para;
	}

	/**
	 * Méthode permettant d'accéder à l'EditParagraph "ep" de la classe DisplayListP.
	 * 
	 * @return Une référence sur l'attribut ep.
	 */
	public EditParagraph getEp() {
		return this.ep;
	}

	/**
	 * Méthode permettant de changer la liste de paragraphe de la classe DisplayListP
	 * 
	 * @param list
	 * 		La nouvelle liste de paragraphes.
	 */
	public void setList(ArrayList<Para> list) {
		this.list = list;
	}

	/**
	 * Méthode permettant de changer l'attribut DisplayGraph
	 * 
	 * @param p
	 * 		Le nouveau DisplayParagraph de la classe.
	 */
	public void setDp(DisplayParagraph p) {
		this.dp = p;
	}

}
