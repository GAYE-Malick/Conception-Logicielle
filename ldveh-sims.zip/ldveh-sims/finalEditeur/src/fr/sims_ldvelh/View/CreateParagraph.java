package fr.sims_ldvelh.View;

import java.awt.Color;
import java.awt.Dimension;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EtchedBorder;

/**
 * La classe s'occupe de la présentation du panel de création d'un paragraphe.<br>
 * 
 * Cette classe a pour attribut(s): 
 * <ul>
 * <li> Un JTextField <b>id</b> qui est l'espace dédié pour la saisie de l'identifiant du paragraphe. </li>
 * <li> Un JTextArea <b>text</b> qui est l'espace dédié pour la saisie du texte du paragraphe. </li>
 * <li> Un JTextArea <b>textC</b> qui est l'espace dédié pour la saisie de la condition de choix du paragraphe. </li>
 * <li> Un JRadioButton <b>aC</b> qui permet de matérialiser le type "alternate_choices" d'un paragraphe. </li>
 * <li> Un JRadioButton <b>tC</b> qui permet de matérialiser le type "trim_choices" d'un paragraphe. </li>
 * </ul>
 * 
 * Cette classe a pour méthode(s): 
 * <ul>
 * <li> Un JTextField <b>getId</b> qui permet d'accéder au JTextField "id" de la classe CreateParagraph.</li>
 * <li> Un JTextArea <b>getText</b> qui permet d'accéder au JTextArea "text" de la classe CreateParagraph.</li>
 * <li> Un JTextArea <b>getTextC</b> qui permet d'accéder au JTextArea "textC" de la classe CreateParagraph.</li>
 * <li> Un JRadioButton <b>getaC</b> qui permet d'accéder au JRadioButton "aC" de la classe CreateParagraph.</li>
 * <li> Un JRadioButton <b>gettC</b> qui permet d'accéder au JRadioButton "tC" de la classe CreateParagraph.</li>
 * </ul>
 * 
 * Veuillez noter que le constructeur n'est pas cité.<br>
 * 
 * @author Ibrahima Sory Bah, Malick Sarr Gaye, Ahouefa Zounon, Steven Martin
 */
public class CreateParagraph extends JPanel {

	/**
	 * Attribut dédié à la saisie de l'identifiant du paragraphe.
	 */
	JTextField id = new JTextField();
	
	/**
	 * L'attribut text dédié à la saisie du texte du paragraphe.
	 * 
	 * L'attribut textC dédié à la saisie de la condition de choix du paragraphe.
	 */
	JTextArea text = new JTextArea(), textC = new JTextArea();
	
	/**
	 * L'attribut aC matérialise le type "alternate_choices" d'un paragraphe.
	 * 
	 * L'attribut tC matérialise le type "trim_choices" d'un paragraphe.
	 */
	JRadioButton aC = new JRadioButton("Alternate Choice"), tC = new JRadioButton("Trim Choice");

	/**
	 * <b>Constructeur de la classe CreateParagraph</b>
	 */
	public CreateParagraph() {

		super();
		this.setBackground(Color.WHITE);
		JScrollPane sp1 = new JScrollPane(), sp2 = new JScrollPane();
		sp1.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.RAISED, new Color(87, 230, 49), null));
		sp2.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.RAISED, new Color(87, 230, 49), null));

		this.setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));

		this.add(Box.createRigidArea(new Dimension(10, 10)));
		this.setAlignmentX(LEFT_ALIGNMENT); // Component...
		this.setAlignmentY(LEFT_ALIGNMENT);

		this.text.setLineWrap(true);
		this.textC.setLineWrap(true);

		this.id.setMaximumSize(new Dimension(100, 50));
		this.text.setPreferredSize(new Dimension(this.getWidth(), 700));
		this.textC.setPreferredSize(new Dimension(this.getWidth(), 80));

		this.add(new JLabel("<html> <h4> L'id du paragraphe </h4> </html>"));
		this.add(this.id);
		this.add(Box.createVerticalStrut(10));

		this.add(new JLabel("<html> <h4> Le texte du paragraphe </h4> </html>"));
		sp1.setViewportView(this.text);
		this.add(sp1);
		this.add(Box.createVerticalStrut(10));

		this.add(new JLabel("<html> <h4> Le texte choice du paragraphe </h4> </html>"));
		sp2.setViewportView(this.textC);
		this.add(sp2);
		this.add(Box.createVerticalStrut(10));

		ButtonGroup bg = new ButtonGroup();
		bg.add(aC);
		bg.add(tC);

		this.add(new JLabel("<html> <h4> Veuillez sélectionner Alternate ou Trim Choice. </h4> </html>"));
		this.add(Box.createVerticalStrut(10));

		this.add(aC);
		this.add(tC);

		this.setBorder(BorderFactory.createTitledBorder("<html> <h2> Créer un paragraphe </h2> </html>"));

	}

// GETTERS ET SETTERS

	/**
	 * Méthode permettant d'accéder au JTextField "id" de la classe CreateParagraph.
	 * 
	 * @return Une référence sur le JTextField "id".
	 */
	public JTextField getId() {
		return this.id;
	}

	/**
	 * Méthode permettant d'accéder au JTextArea "text" de la classe CreateParagraph.
	 * 
	 * @return Une référence sur le JTextArea "text".
	 */
	public JTextArea getText() {
		return this.text;
	}

	/**
	 * Méthode permettant d'accéder au JTextArea "textC" de la classe CreateParagraph.
	 * 
	 * @return Une référence sur le JTextArea "textC".
	 */
	public JTextArea getTextC() {
		return this.textC;
	}

	/**
	 * Méthode permettant d'accéder au JRadioButton "aC" de la classe CreateParagraph.
	 * 
	 * @return Une référence sur le JRadioButton "aC".
	 */
	public JRadioButton getaC() {
		return this.aC;
	}

	/**
	 * Méthode permettant d'accéder au JRadioButton "tC" de la classe CreateParagraph.
	 * 
	 * @return Une référence sur le JRadioButton "tC".
	 */
	public JRadioButton gettC() {
		return this.tC;
	}

}
