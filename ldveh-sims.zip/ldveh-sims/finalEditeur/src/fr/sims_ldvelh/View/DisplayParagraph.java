package fr.sims_ldvelh.View;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;

import fr.sims_ldvelh.Model.Para;

/**
 * La classe s'occupe de l'affichage d'un paragraphe.<br>
 * 
 * Cette classe n'a aucun attribut. <br>
 * Cette classe n'a aucune méthode.<br>
 * Veuillez noter que le constructeur n'est pas cité.<br>
 * 
 * @author Ibrahima Sory Bah, Malick Sarr Gaye, Ahouefa Zounon, Steven Martin
 */
public class DisplayParagraph extends JPanel {

	/**
	 * <b>Constructeur de la classe DisplayParagraph</b>
	 * 
	 * @param p
	 * 		Le paragraphe a afficher.
	 */
	public DisplayParagraph(Para p) {

		super();
		this.setBackground(Color.WHITE);

		JPanel milieu = new JPanel();
		milieu.setBackground(Color.WHITE);
		this.setBackground(Color.WHITE);

		milieu.setLayout(new BoxLayout(milieu, BoxLayout.PAGE_AXIS));
		milieu.add(Box.createRigidArea(new Dimension(10, 10)));

		milieu.add(new JLabel("<html> <h4> Texte </h4> <br/> <br/> <p>" + p.getText()));
		milieu.add(Box.createVerticalStrut(10));
		milieu.add(new JLabel("<html> <h4> Condition de choix </h4> <br/> <br/> <p>" + p.getChoiceText()));
		milieu.add(Box.createVerticalStrut(10));

		if (p.getAlternate_choices()) {
			milieu.add(new JLabel("<html> <h4> Alternate Choice </h4> </html>"));
		} else if (p.isTrim_choices()) {
			milieu.add(new JLabel("<html> <h4> Trim Choice </h4> </html>"));
		} else {
			milieu.add(new JLabel(
					"<html> <h4> Vous n'avez rien sélectionné entre Alternate Choice et Trim Choice </h4> </html>"));
		}

		JLabel word = new JLabel();

		for (int i = 0; i < p.getWords().size(); i++) {
			word.setText(word.getText() + p.getWords().get(i) + " ");
		}

		JLabel choice = new JLabel();

		for (int i = 0; i < p.getChoicesList().size(); i++) {
			choice.setText(choice.getText() + "Para " + p.getChoicesList().get(i).getID() + " ");
		}

		milieu.add(Box.createVerticalStrut(10));
		milieu.add(new JLabel("<html> <h4> Liste des pouvoirs </h4> <br/> <p>"));
		milieu.add(word);
		milieu.add(Box.createVerticalStrut(10));
		milieu.add(new JLabel("<html> <h4> Liste des choix </h4> <br/> <p>"));
		milieu.add(choice);

		this.setLayout(new BorderLayout());
		this.add(milieu, BorderLayout.CENTER);

		this.setBorder(BorderFactory.createTitledBorder("<html> <h2> Paragraphe " + p.getID() + " </h2> </html>"));
	}

}
