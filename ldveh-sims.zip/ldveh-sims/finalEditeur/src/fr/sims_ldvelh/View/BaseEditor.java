package fr.sims_ldvelh.View;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;

import fr.sims_ldvelh.Controller.BaseEditorControl;
import fr.sims_ldvelh.Controller.ClosedWindowListener;

/**
 * La classe s'occupe de l'affichage de la fenêtre de base.<br>
 * 
 * Cette classe a pour attribut(s): 
 * <ul>
 * <li> Un JPanel <b>pane</b> qui est le JPanel de base. </li>
 * <li> Un JButton <b>finishCreatePara</b> qui permet de notifier au système que tous les paragraphes ont été créés. </li>
 * <li> Un JButton <b>finishModifPara</b> qui permet de notifier au système que toutes les modifications sur les paragraphes ont été réalisées. </li>
 * <li> Un JButton <b>createBook</b> qui permet de notifier au système que l'on est prêt à créer le livre. </li>
 * <li> Un FirstEditor <b>fE</b> qui représente le JPanel pour la gestion de la crétion des paragraphes du livre. </li>
 * <li> Un SecondEditor <b>sE</b> qui représente le JPanel pour la gestion des modifications des paragraphes du livre. </li>
 * <li> Un ThirdEditor <b>tE</b> qui représente le JPanel pour la gestion du graphe du livre. </li>
 * <li> Un ReadTheBook <b>rtb</b> qui représente le JPanel pour la lecture du livre. </li>
 * <li> Un JMenuItem <b>openFile</b> qui doit permettre la lecture de n'importe quel livre importé en .JSON. </li>
 * <li> Un JMenuItem <b>quitApply</b> qui permet de fermer la fenêtre. </li>
 * </ul>
 * 
 * Cette classe a pour méthode(s): 
 * <ul>
 * <li> Un JButton <b>getFinishCreatePara</b> qui permet d'accéder au bouton "finishCreatePara" de la classe BaseEditor.</li>
 * <li> Un JButton <b>getFinishModifPara</b> qui permet d'accéder au bouton "finishModifPara" de la classe BaseEditor.</li>
 * <li> Un JButton <b>getCreateBook</b> qui permet d'accéder au bouton "createBook" de la classe BaseEditor.</li>
 * <li> Un JPanel <b>getPane</b> qui permet d'accéder au JPanel de base "pane" de la classe BaseEditor.</li>
 * <li> Un JMenuItem <b>getOuvrir</b> qui permet d'accéder à l'item de menu "openFile" de la classe BaseEditor.</li>
 * <li> Un JMenuItem <b>getQuitter</b> qui permet d'accéder à l'item de menu "quitApply" de la classe BaseEditor.</li>
 * <li> Un FirstEditor <b>getfE</b> qui permet d'accéder au FirstEditor "fE" de la classe BaseEditor.</li>
 * <li> Un SecondEditor <b>getsE</b> qui permet d'accéder au SecondEditor "sE" de la classe BaseEditor.</li>
 * <li> Un ThirdEditor <b>gettE</b> qui permet d'accéder au ThirdEditor "tE" de la classe BaseEditor.</li>
 * <li> Un ReadTheBook <b>getRtb</b> qui permet d'accéder au ReadTheBook "rtb" de la classe BaseEditor.</li>
 * <li> Un void <b>setRtb</b> qui permet de modifier l'attribut "rtb" de la classe BaseEditor.</li>
 * <li> Un void <b>setsE</b> qui permet de modifier l'attribut "sE" de la classe BaseEditor.</li>
 * <li> Un void <b>settE</b> qui permet de modifier l'attribut "tE" de la classe BaseEditor.</li>
 * </ul>
 * 
 * Veuillez noter que le constructeur n'est pas cité.<br>
 * 
 * @author Ibrahima Sory Bah, Malick Sarr Gaye, Ahouefa Zounon, Steven Martin
 */
public class BaseEditor extends JFrame {

	/**
	 * Attribut représentant le JPanel de base de la JFrame BaseEditor contenant tous les autres.
	 */
	private JPanel pane = new JPanel();
	
	/**
	 * Bouton permettant de notifier le système lorque tous les paragraphes ont été créés.
	 */
	private JButton finishCreatePara = new JButton("Tous les paragraphes sont crées.");
	
	/**
	 * Bouton permettant de notifier le système lorque toutes les modifications sur les paragraphes ont été réalisées.
	 */
	private JButton finishModifPara = new JButton("Toutes les modifications sont faites.");
	
	/**
	 * Bouton permettant de notifier le système lorque que l'on est prêt pour céer le livre.
	 */
	private JButton createBook = new JButton("Créer livre");

	/**
	 * Le JPanel destiné à la gestion de la crétion des paragraphes du livre.
	 */
	private FirstEditor fE;
	
	/**
	 * Le JPanel destiné à la gestion des modifications sur les paragraphes du livre.
	 */
	private SecondEditor sE;
	
	/**
	 * Le JPanel destiné à la gestion du graphe du livre.
	 */
	private ThirdEditor tE;
	
	/**
	 * Le JPanel destiné à la lecture du livre.
	 */
	private ReadTheBook rtb;
	
	/**
	 * Le JMenuItem openFile doit permettre la lecture de n'importe quel livre importé en .JSON.<br>
	 * 
	 * Le JMenuItem quitApply permet de fermer la fenêtre.
	 */
	private JMenuItem openFile, quitApply;

	/**
	 * <b>Constructeur de la classe BaseEditor</b>
	 */
	public BaseEditor() {

		super("SIMS - Editeur de LDVELH");
		this.setBackground(Color.WHITE);

		// TODO L'icône et les paramètres de la fenêtre
		Image logo = Toolkit.getDefaultToolkit().getImage("src/images/logo.png");
		this.setIconImage(logo);
		this.setSize(Toolkit.getDefaultToolkit().getScreenSize());
		this.setExtendedState(JFrame.MAXIMIZED_BOTH);

		// TODO Le menu
		JMenuBar menu = new JMenuBar();
		menu.setLayout(new FlowLayout(FlowLayout.LEFT));

		JMenu file = new JMenu("Fichier");
		this.openFile = new JMenuItem("Ouvrir...");
		this.quitApply = new JMenuItem("Quitter");
		
		BaseEditorControl bec = new BaseEditorControl(this);
		this.openFile.addActionListener(bec);
		this.quitApply.addActionListener(bec);

		file.add(this.openFile);
		file.addSeparator();
		file.add(this.quitApply);

		menu.add(file);

		this.setJMenuBar(menu);

		// TODO Le contenu
		Container edit = this.getContentPane();

		this.pane.setLayout(new BorderLayout());

		this.fE = new FirstEditor();

		this.pane.add(this.fE, BorderLayout.CENTER);
		this.pane.add(this.finishCreatePara, BorderLayout.SOUTH);

		this.finishCreatePara.addActionListener(new BaseEditorControl(this));
		this.finishModifPara.addActionListener(new BaseEditorControl(this));
		this.createBook.addActionListener(new BaseEditorControl(this));

		edit.add(this.pane);

		// TODO A la fermerture de la fenêtre
		ClosedWindowListener cwl = new ClosedWindowListener(this);
		this.addWindowListener(cwl);
		this.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		this.pack();
		this.setVisible(true);

	}

	// GETTERS ET SETTERS

	/**
	 * Méthode permettant d'accéder au bouton "finishCreatePara" de la classe BaseEditor.
	 * 
	 * @return Une référence sur le bouton "finishCreatePara".
	 */
	public JButton getFinishCreatePara() {
		return this.finishCreatePara;
	}

	/**
	 * Méthode permettant d'accéder au bouton "finishModifPara" de la classe BaseEditor.
	 * 
	 * @return Une référence sur le bouton "finishModifPara".
	 */
	public JButton getFinishModifPara() {
		return this.finishModifPara;
	}

	/**
	 * Méthode permettant d'accéder au bouton "createBook" de la classe BaseEditor.
	 * 
	 * @return Une référence sur le bouton "createBook".
	 */
	public JButton getCreateBook() {
		return this.createBook;
	}

	/**
	 * Méthode permettant d'accéder au JPanel "pane" de la classe BaseEditor.
	 * 
	 * @return Une référence sur le JPanel "pane".
	 */
	public JPanel getPane() {
		return this.pane;
	}

	/**
	 * Méthode permettant d'accéder au JMenuItem "openFile" de la classe BaseEditor.
	 * 
	 * @return Une référence sur le JMenuItem "openFile".
	 */
	public JMenuItem getOuvrir() {
		return this.openFile;
	}

	/**
	 * Méthode permettant d'accéder au JMenuItem "quitApply" de la classe BaseEditor.
	 * 
	 * @return Une référence sur le JMenuItem "quitApply".
	 */
	public JMenuItem getQuitter() {
		return this.quitApply;
	}

	/**
	 * Méthode permettant d'accéder au JPanel FirstEditor "fE" de la classe BaseEditor.
	 * 
	 * @return Une référence sur le FirstEditor "fE".
	 */
	public FirstEditor getfE() {
		return this.fE;
	}

	/**
	 * Méthode permettant d'accéder au JPanel SecondEditor "sE" de la classe BaseEditor.
	 * 
	 * @return Une référence sur le SecondEditor "sE".
	 */
	public SecondEditor getsE() {
		return this.sE;
	}

	/**
	 * Méthode permettant d'accéder au JPanel ThirdEditor "tE" de la classe BaseEditor.
	 * 
	 * @return Une référence sur le ThirdEditor "tE".
	 */
	public ThirdEditor gettE() {
		return this.tE;
	}

	/**
	 * Méthode permettant d'accéder au JPanel ReadTheBook "rtb" de la classe BaseEditor.
	 * 
	 * @return Une référence sur le ReadTheBook "rtb".
	 */
	public ReadTheBook getRtb() {
		return this.rtb;
	}

	/**
	 * Méthode permettant de modifier l'attribut "rtb" de la classe BaseEditor.
	 * 
	 * @param rtb
	 * 		Le nouveau ReadTheBook.
	 */
	public void setRtb(ReadTheBook rtb) {
		this.rtb = rtb;
	}

	/**
	 * Méthode permettant de modifier l'attribut "sE" de la classe BaseEditor.
	 * 
	 * @param sE
	 * 		Le nouveau SecondEditor.
	 */
	public void setsE(SecondEditor sE) {
		this.sE = sE;
	}

	/**
	 * Méthode permettant de modifier l'attribut "tE" de la classe BaseEditor.
	 * 
	 * @param tE
	 * 		Le nouveau ThirdEditor.
	 */
	public void settE(ThirdEditor tE) {
		this.tE = tE;
	}

}
