package fr.sims_ldvelh.View;

import java.awt.BorderLayout;
import java.awt.Color;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import fr.sims_ldvelh.Controller.ThirdEditorControl;
import fr.sims_ldvelh.Model.Graphe;
import fr.sims_ldvelh.Model.Para;

/**
 * La classe s'occupe des modifications des paragraphes du livre.<br>
 * 
 * Cette classe a pour attribut(s): 
 * <ul>
 * <li> Un JButton <b>addRacine</b> </li>
 * <li> Un JButton <b>retNoeud</b> </li>
 * <li> Un DisplayGraph <b>dg</b> </li>
 * <li> Un JScrollPane <b>sp</b> </li>
 * <li> Un ArrayList <b>listPara</b> de Para </li>
 * <li> Un JPanel <b>leftSide</b> </li>
 * <li> Un Graphe <b>graph</b> </li>
 * </ul>
 * 
 * Cette classe a pour méthode(s): 
 * <ul>
 * <li> Un JButton <b>getAddRacine</b> </li>
 * <li> Un JButton <b>getRetRacine</b> </li>
 * <li> Un JScrollPane <b>getSp</b> </li>
 * <li> Un DisplayGraph <b>getDg</b> </li>
 * <li> Un ArrayList <b>getList</b> de Para </li>
 * <li> Un JPanel <b>getLeftSide</b> </li>
 * <li> Un Graphe <b>getGraph</b> </li>
 * <li> Un void <b>setGraph</b> </li>
 * <li> Un void <b>setDg</b> </li>
 * <li> Un ArrayList <b>toList</b> d'Integer </li>
 * </ul>
 * 
 * Veuillez noter que le constructeur n'est pas cité.<br>
 * 
 * @author Ibrahima Sory Bah, Malick Sarr Gaye, Ahouefa Zounon, Steven Martin
 */
public class ThirdEditor extends JPanel {

	/**
	 * Attribut addRacine représentant l'action d'ajouter la racine du graphe.
	 * 
	 * Attribut retNoeud représentant l'action de retirer un noeud du graphe.
	 */
	private JButton addRacine = new JButton("Ajouter la racine"), retNoeud = new JButton("Retirer un noeud");
	
	/**
	 * Attribut représentant le panel qervant à l'affichage du graphe.
	 */
	private DisplayGraph dg;
	
	/**
	 * Attribut représentant le panneau dans le quel est placé le DisplayGraph dg.
	 */
	private JScrollPane sp;
	
	/**
	 * Attribut représentant la liste des paragraphes.
	 */
	private ArrayList<Para> list;
	
	/**
	 * Attribut représentant la partie gauche comportant les boutons.
	 */
	private JPanel leftSide;
	
	/**
	 * Attribut représentant le graphe du livre.
	 */
	private Graphe graph;

	/**
	 * <b>Constructeur de la classe ThirdEditor</b>
	 * 
	 * @param list
	 * 		La liste avec laquelle on initialise la liste de paragraphe lors de la création d'un ThirdEditor.
	 */
	public ThirdEditor(ArrayList<Para> list) {

		super();
		this.setBackground(Color.WHITE);

		this.list = list;
		this.setLayout(new BorderLayout());

		ThirdEditorControl tec = new ThirdEditorControl(this);
		this.addRacine.addActionListener(tec);
		this.retNoeud.addActionListener(tec);

		this.leftSide = new JPanel();
		this.leftSide.setLayout(new BoxLayout(this.leftSide, BoxLayout.PAGE_AXIS));
		this.leftSide.add(this.addRacine);
		// leftSide.add(this.retNoeud);

		this.dg = new DisplayGraph();

		this.sp = new JScrollPane(this.dg);
		this.sp.setBorder(BorderFactory.createTitledBorder("<html> <h2> Graphe </h2> </html>"));

		this.add(this.leftSide, BorderLayout.WEST);
		this.add(this.sp, BorderLayout.CENTER);

	}

	/**
	 * Méthode permettant de récupérer tous les identifiants d'une liste de paragraphes.
	 * 
	 * @param list
	 * 		La liste de paragraphes dont on doit récupérer les identifiants.
	 * 
	 * @return La liste des identifiants des paragraphes de la liste list.
	 */
	public ArrayList<Integer> toList(ArrayList<Para> list) {

		ArrayList<Integer> listInt = new ArrayList<Integer>();

		for (int i = 0; i < list.size(); i++) {
			listInt.add(list.get(i).getID());
		}

		return listInt;
	}

// GETTERS ET SETTERS

	/**
	 * Méthode permettant d'accéder au JButton "addRacine" de la classe ThirdEditor.
	 * 
	 * @return Une référence sur l'attribut addRacine.
	 */
	public JButton getAddRacine() {
		return this.addRacine;
	}

	/**
	 * Méthode permettant d'accéder au JButton "retNoeud" de la classe ThirdEditor.
	 * 
	 * @return Une référence sur l'attribut retNoeud.
	 */
	public JButton getRetNoeud() {
		return this.retNoeud;
	}

	/**
	 * Méthode permettant d'accéder au JScrollPane "sp" de la classe ThirdEditor.
	 * 
	 * @return Une référence sur l'attribut sp.
	 */
	public JScrollPane getSp() {
		return this.sp;
	}

	/**
	 * Méthode permettant d'accéder au DisplayGraph "dg" de la classe ThirdEditor.
	 * 
	 * @return Une référence sur l'attribut dg.
	 */
	public DisplayGraph getDg() {
		return this.dg;
	}

	/**
	 * Méthode permettant d'accéder à la liste de paragraphes de la classe ThirdEditor.
	 * 
	 * @return Une référence sur l'attribut list.
	 */
	public ArrayList<Para> getList() {
		return this.list;
	}

	/**
	 * Méthode permettant d'accéder au JPanel "leftSide" de la classe ThirdEditor.
	 * 
	 * @return Une référence sur l'attribut leftSide.
	 */
	public JPanel getLeftSide() {
		return this.leftSide;
	}

	/**
	 * Méthode permettant d'accéder au graphe de la classe ThirdEditor.
	 * 
	 * @return Une référence sur l'attribut graph.
	 */
	public Graphe getGraph() {
		return this.graph;
	}

	/**
	 * Méthode permettant de changer le graphe de la classe ThirdEditor
	 * 
	 * @param graph
	 * 		Le nouveau graphe.
	 */
	public void setGraph(Graphe graph) {
		this.graph = graph;
	}

	/**
	 * Méthode permettant de changer le DisplayGraph de la classe ThirdEditor
	 * 
	 * @param dg
	 * 		Le nouveau DisplayGraph.
	 */
	public void setDg(DisplayGraph dg) {
		this.dg = dg;
	}

}
