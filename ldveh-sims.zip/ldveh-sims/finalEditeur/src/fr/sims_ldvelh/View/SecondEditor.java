package fr.sims_ldvelh.View;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import fr.sims_ldvelh.Controller.SecondEditorControl;
import fr.sims_ldvelh.Model.Para;

/**
 * La classe s'occupe des modifications des paragraphes du livre.<br>
 * 
 * Cette classe a pour attribut(s): 
 * <ul>
 * <li> Un DisplayListP <b>dlp</b> </li>
 * <li> Un EditParagraph <b>ep</b> </li>
 * <li> Un ArrayList <b>listPara</b> de Para </li>
 * <li> Un JScrollPane <b>sp</b> de Para </li>
 * <li> Un JPanel <b>rightSide</b> </li>
 * <li> Un JButton <b>annulerModifP</b> </li>
 * <li> Un JButton <b>finishModifP</b> </li>
 * </ul>
 * 
 * Cette classe a pour méthode(s): 
 * <ul>
 * <li> Un ArrayList <b>getListPara</b> de Para. </li>
 * <li> Un DisplayListP <b>getDlp</b> </li>
 * <li> Un JPanel <b>getRightSide</b> </li>
 * <li> Un JButton <b>getAnnulerModifP</b> </li>
 * <li> Un JButton <b>getFinishModifP</b> </li>
 * <li> Un EditParagraph <b>getEp</b> </li>
 * <li> Un JScrollPane <b>getSp</b> </li>
 * <li> Un void <b>getDlp</b> </li>
 * <li> Un void <b>getEp</b> </li>
 * </ul>
 * 
 * Veuillez noter que le constructeur n'est pas cité.<br>
 * 
 * @author Ibrahima Sory Bah, Malick Sarr Gaye, Ahouefa Zounon, Steven Martin
 */
public class SecondEditor extends JPanel {

	/**
	 * Attribut représentant l'affichage de la liste de paragraphes.
	 */
	private DisplayListP dlp;
	
	/**
	 * Attribut représentant le panel d'édition d'un paragraphe.
	 */
	private EditParagraph ep;
	
	/**
	 * Attribut représentant la liste de paragraphes.
	 */
	private ArrayList<Para> listPara;

	/**
	 * Attribut représentant le panneau dans le quel est placé la liste de paragraphe gérée pars la JList DisplayListP
	 */
	private JScrollPane sp;
	
	/**
	 * Attribut représentant la partie droite du panel.
	 */
	private JPanel rightSide = new JPanel();
	
	/**
	 * Attribut annulerModifP représentant l'action d'annuler toutes les modifications faites sur le paragraphe en cours d'édition dans le RightSide.
	 * 
	 * Attribut finishModifP représentant l'action d'enrégistrer toutes les modifications faites sur le paragraphe en cours d'édition dans le RightSide.
	 */
	private JButton annulerModifP = new JButton("Annuler"), finishModifP = new JButton("Terminer");

	/**
	 * <b>Constructeur de la classe SecondEditor</b>
	 * 
	 * @param list
	 * 		La liste avec laquelle on initialise la liste de paragraphe lors de la création d'un SecondEditor.
	 */
	public SecondEditor(ArrayList<Para> list) {

		super();
		this.setBackground(Color.WHITE);

		this.listPara = list;

		this.dlp = new DisplayListP(this);

		this.sp = new JScrollPane(this.dlp);
		this.rightSide.setLayout(new BorderLayout());

		this.sp.setBorder(BorderFactory.createTitledBorder("<html> <h2> Liste des paragraphes </h2> </html>"));

		SecondEditorControl sec = new SecondEditorControl(this);
		this.annulerModifP.addActionListener(sec);
		this.finishModifP.addActionListener(sec);

		this.setLayout(new GridLayout(1, 2));
		this.add(this.sp);
		this.add(this.rightSide);

	}

// GETTERS ET SETTERS

	/**
	 * Méthode permettant d'accéder à la liste de paragraphes de la classe SecondEditor.
	 * 
	 * @return Une référence sur l'attribut listPara.
	 */
	public ArrayList<Para> getListPara() {
		return this.listPara;
	}

	/**
	 * Méthode permettant d'accéder au DisplayListP "dlp" de la classe SecondEditor.
	 * 
	 * @return Une référence sur l'attribut dlp.
	 */
	public DisplayListP getDlp() {
		return this.dlp;
	}

	/**
	 * Méthode permettant d'accéder au JPanel "rightSide" de la classe SecondEditor.
	 * 
	 * @return Une référence sur l'attribut rightSide.
	 */
	public JPanel getRightSide() {
		return this.rightSide;
	}

	/**
	 * Méthode permettant d'accéder au JButton "annulerModifP" de la classe SecondEditor.
	 * 
	 * @return Une référence sur l'attribut annulerModifP.
	 */
	public JButton getAnnulerModifP() {
		return this.annulerModifP;
	}

	/**
	 * Méthode permettant d'accéder au JButton "finishModifP" de la classe SecondEditor.
	 * 
	 * @return Une référence sur l'attribut finishModifP.
	 */
	public JButton getFinishModifP() {
		return this.finishModifP;
	}

	/**
	 * Méthode permettant d'accéder au EditParagraph "ep" de la classe SecondEditor.
	 * 
	 * @return Une référence sur l'attribut ep.
	 */
	public EditParagraph getEp() {
		return this.ep;
	}

	/**
	 * Méthode permettant d'accéder au JScrollPane "sp" de la classe SecondEditor.
	 * 
	 * @return Une référence sur l'attribut sp.
	 */
	public JScrollPane getSp() {
		return this.sp;
	}

	/**
	 * 
	 * Méthode permettant de changer la JList DisplayListP de la classe SecondEditor
	 * 
	 * @param dlp
	 * 		La nouvelle DisplayListP.
	 */
	public void setDlp(DisplayListP dlp) {
		this.dlp = dlp;
	}

	/**
	 * 
	 * Méthode permettant de changer le panel EditParagraph de la classe SecondEditor
	 * 
	 * @param ep
	 * 		Le nouvel EditParagraph
	 */
	public void setEp(EditParagraph ep) {
		this.ep = ep;
	}

}
