package fr.sims_ldvelh.View;

import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;

import javax.swing.JOptionPane;
import javax.swing.JPanel;

import fr.sims_ldvelh.Model.Para;

/**
 * La classe s'occupe de la présentation du graphe.<br>
 * 
 * Cette classe a pour attribut(s): 
 * <ul>
 * <li> Un int <b>w</b> qui est la largeur des éléments repreésentant un paragraphe dans le dessin du graphe. </li>
 * <li> Un int <b>h</b> qui est la hauteur des éléments repreésentant un paragraphe dans le dessin du graphe. </li>
 * <li> Un Para <b>p</b> qui est le paragraphe racine du graphe. </li>
 * <li> Un ArrayList <b>list</b> d'Integer qui est la liste des identifiants des paragraphes. </li>
 * <li> Un ArrayList <b>listP</b> de Para qui est la liste des paragraphes. </li>
 * </ul>
 * 
 * Cette classe a pour méthode(s): 
 * <ul>
 * <li> Un boolean <b>recherche</b> qui permet de rechercher l'id d'un paragraphe dans la liste d'identifiants.</li>
 * <li> Un void <b>dessinerLigne</b> qui permet de tracer des lignes entre les différents paragraphes.</li>
 * <li> Un void <b>dessinerPara</b> qui permet de déssiner un paragraphe.</li>
 * <li> Un void <b>dessinerGraphe</b> qui permet de déssiner le graphe.</li>
 * <li> Un void <b>paintComponent</b> qui permet d'afficher la classe 1displayGraph et par la même occasion d'afficher le graphe.</li>
 * <li> Un void <b>pause</b> qui permet d'intérrompre le thread courant pendant un nombre de milli-secondes donné.</li>
 * <li> Un ArrayList <b>getList</b> d'Integer qui permet d'accéder à la liste d'identifiants de paragraphes "list" de la classe DisplayGraph.</li>
 * <li> Un Para <b>getP</b> qui permet d'accéder au paragraphe racine "listP" de la classe DisplayGraph.</li>
 * <li> Un void <b>setP</b> qui permet de modifier le paragraphe racine de la classe DisplayGraph.</li>
 * <li> Un ArrayList <b>gettC</b> de Para qui permet d'accéder à la liste de paragraphe "listP" de la classe DisplayGraph.</li>
 * </ul>
 * 
 * Veuillez noter que le constructeur n'est pas cité.<br>
 * 
 * @author Ibrahima Sory Bah, Malick Sarr Gaye, Ahouefa Zounon, Steven Martin
 */
public class DisplayGraph extends JPanel {

	/**
	 * L'attribut w pour la largeur et l'attribut h pour la hauteur.
	 */
	private static final int w = 40, h = 30;
	//private FontMetrics fm = getFontMetrics(getFont());
	
	/**
	 * Attribut représentant le paragraphe racine du graphe.
	 */
	private Para p;
	
	/**
	 * Attribut représentant la liste des identifiants des paragraphes.
	 */
	private ArrayList<Integer> list = new ArrayList<Integer>();
	
	/**
	 * Attribut représentant la liste des paragraphes.
	 */
	private ArrayList<Para> listP = new ArrayList<Para>();

	/**
	 * <b>Constructeur de la classe DisplayGraph</b>
	 * 
	 */
	public DisplayGraph() {

		super();
		this.setBackground(Color.WHITE);
	}

	/**
	 * Méthode permettant de rechercher l'id d'un paragraphe dans la liste d'identifiants.
	 * 
	 * @param p
	 * 		Le paragraphe dont on doit chercher l'identifiant.
	 * 
	 * @return Un booléen à <code>true</code> si l'identifiant du paragraphe est dans la liste sinon à <code>false</code>.
	 */
	public boolean recherche(Para p) {

		if (this.list.contains(p.getID())) {
			return true;
		} else
			return false;

	}

	/**
	 * Méthode permettant de tracer des lignes entre les différents paragraphes.
	 * 
	 * @param g
	 * 		Le graphics g. Peut être comparer à un pinceau.
	 * @param A
	 * 		Le paragraphe courant considéré comme parent
	 * @param B
	 * 		Le paragraphe considéré comme successeur
	 */
	public void dessinerLigne(Graphics g, Para A, Para B) {

		int decA = w; // + fm.stringWidth( Integer.toString(A.getID()) );
		int decB = w; // + fm.stringWidth( Integer.toString(B.getID()) );

		if (B.getPosY() < A.getPosY()) { //Si le paragraphe B à une profondeur plus petite que le paragraphe A.
			
			g.drawLine(A.getPosX() + (decA / 2), A.getPosY(), B.getPosX() + (decB / 2), B.getPosY() + h);
		}

		else if (B.getPosY() > A.getPosX()) { //Si le paragraphe A à une profondeur plus petite que le paragraphe B.
			
			g.drawLine(A.getPosX() + (decA / 2), A.getPosY() + h, B.getPosX() + (decB / 2), B.getPosY());
		}

		else { //Si les deux paragraphes A et B ont la même profondeur.
			
			g.drawLine(B.getPosX() + decB, B.getPosY() + (h / 2), A.getPosX(), A.getPosY() + (h / 2));
		}
	}

	/**
	 * Méthode permettant de déssiner un paragraphe.
	 * 
	 * @param g
	 * 		Le graphics g. Peut être comparer à un pinceau.
	 * @param A
	 * 		Le paragraphe courant considéré comme noeud
	 * @param posX
	 * 		La position X où doit-être placé le paragraphe
	 * @param posY
	 * 		La position Y où doit-être placé le paragraphe
	 * @param pasX
	 * 		La largeur de l'élément représentant le paragraphe.
	 * @param pasY
	 * 		La hauteur de l'élément représentant le paragraphe.
	 */
	public void dessinerPara(Graphics g, Para A, int posX, int posY, int pasX, int pasY) {
		
		this.pause(500);
		try {
			String str = Integer.toString(A.getID());
			A.setPosX(posX);
			A.setPosY(posY);
			int i = pasX / 2;
			int j = pasY / 2;

			g.setColor(Color.GRAY);
			g.fillOval(posX, posY, pasX, pasY); // 21+fm.stringWidth(str),21);
			g.setColor(Color.BLACK);
			g.drawString(str, posX + i, posY + j); // on dessine la valeur du noeud
		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(this, "<html> <h2> Le paragraphe n'existe pas! </h2> </html> ", "SIMS-Erreur",
					JOptionPane.ERROR_MESSAGE);
		}
	}

	/**
	 * Méthode permettant de déssiner le graphe.
	 * 
	 * @param g
	 * 		Le graphics g. Peut être comparer à un pinceau.
	 * @param A
	 * 		Le paragraphe courant considéré comme noeud
	 * @param posX
	 * 		La position X où doit-être placé le paragraphe
	 * @param posY
	 * 		La position Y où doit-être placé le paragraphe
	 * @param pasX
	 * 		La largeur de l'élément représentant le paragraphe.
	 * @param pasY
	 * 		La hauteur de l'élément représentant le paragraphe.
	 */
	public void dessinerGraphe(Graphics g, Para A, int posX, int posY, int pasX, int pasY) {

		//String str = Integer.toString(A.getID());
		A.setPosX(posX);
		A.setPosY(posY);

		this.list.add(A.getID());
		this.listP.add(A);

		dessinerPara(g, A, posX, posY, pasX, pasY);
		int dec = pasX;

		if (A.getChoicesList().size() != 0) {
			if (A.getChoicesList().size() == 1) {
				if (recherche(A.getChoicesList().get(0))) {
					dessinerLigne(g, A, A.getChoicesList().get(0));
				}

				else {
					g.drawLine(posX + (dec / 2), posY + pasY, posX + (dec / 2), posY + pasY + h);
					dessinerGraphe(g, A.getChoicesList().get(0), posX, posY + pasY + h, pasX, pasY);
				}
			}

			else {
				for (int i = 1; i <= A.getChoicesList().size(); i++) {
					if (recherche(A.getChoicesList().get(i - 1))) {
						dessinerLigne(g, A, A.getChoicesList().get(i - 1));
					}

					else {
						float ess = i;
						g.drawLine(posX + (dec / 2), posY + pasY, (int) ((ess / 2) * posX), posY + pasY + h);
						dessinerGraphe(g, A.getChoicesList().get(i - 1), (int) ((ess / 2) * posX) - (pasX / 2),
								posY + pasY + h, pasX, pasY);
					}
				}
			}
		}
	}

	/**
	 * Méthode permettant d'afficher la classe 1displayGraph et par la même occasion d'afficher le graphe.
	 */
	@Override
	public void paintComponent(Graphics g) {

		if (this.p != null) {
			if (this.p.getID() != null) {
				int pos = this.getWidth() / 2;
				dessinerGraphe(g, this.p, pos, 0, w, h);
			}
		}

	}

	/**
	 * Méthode permettant d'intérrompre le thread courant pendant un nombre de milli-secondes donné.
	 * 
	 * @param time
	 * 		Le nombre de milli-secondes pendant lequel le thread doi être intérrompu.
	 * 
	 * @throws InterruptedException Déclanchée si l'on arrive pas à intérrompre le thread en cours.
	 */
	public void pause(int time) { // pause pour observer la construction de l'arbre
		try {
			Thread.sleep(time);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	// GETTERS ET SETTERS

	/**
	 * Méthode permettant d'accéder à la liste d'identifiants de paragraphes "list" de la classe DisplayGraph.
	 * 
	 * @return Une référence sur la liste list.
	 */
	public ArrayList<Integer> getList() {
		return this.list;
	}

	/**
	 * Méthode permettant d'accéder au paragraphe racine "listP" de la classe DisplayGraph.
	 * 
	 * @return Une référence sur le paragraphe racine p.
	 */
	public Para getP() {
		return this.p;
	}

	/**
	 * Méthode permettant de modifier le paragraphe racine de la classe DisplayGraph.
	 * 
	 * @param p
	 * 		Le nouveau paragraphe racine.
	 */
	public void setP(Para p) {
		this.p = p;
	}

	/**
	 * Méthode permettant d'accéder à la liste de paragraphe "listP" de la classe DisplayGraph.
	 * 
	 * @return Une référence sur la liste listP.
	 */
	public ArrayList<Para> getListP() {
		return this.listP;
	}
	
}
