package fr.sims_ldvelh.View;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

import fr.sims_ldvelh.Controller.ReadTheBookControl;
import fr.sims_ldvelh.Model.Para;

/**
 * La classe s'occupe de la lecture du livre.<br>
 * 
 * Cette classe a pour attribut(s): 
 * <ul>
 * <li> Un JButton <b>readBook</b> </li>
 * <li> Un JScrollPane <b>sp</b> </li>
 * <li> Un JLabel <b>textP</b> </li>
 * <li> Un JLabel <b>textChoices</b> </li>
 * <li> Un JTextField <b>choice</b> </li>
 * <li> Un JPanel <b>leftSide</b> </li>
 * <li> Un JPanel <b>rightSide</b> </li>
 * <li> Un JButton <b>ok</b> </li>
 * <li> Un ArrayList <b>listP</b> de Para </li>
 * </ul>
 * 
 * Cette classe a pour méthode(s): 
 * <ul>
 * <li> Un SecondEditor <b>getsE</b> </li>
 * <li> Un ArrayList <b>getList</b> de Para. </li>
 * <li> Un JPopupMenu <b>getMenu</b> </li>
 * <li> Un JMenuItem <b>getDisp</b> </li>
 * <li> Un JMenuItem <b>getEditer</b> </li>
 * <li> Un JMenuItem <b>getDel</b> </li>
 * <li> Un JMenuItem <b>getDp</b> </li>
 * <li> Un JMenuItem <b>getAddC</b> </li>
 * <li> Un JMenuItem <b>getRemC</b> </li>
 * <li> Un JMenuItem <b>getRemCT</b> </li>
 * <li> Un JMenuItem <b>getAddW</b> </li>
 * <li> Un JMenuItem <b>getRemW</b> </li>
 * <li> Un JMenuItem <b>getRemWT</b> </li>
 * </ul>
 * 
 * Veuillez noter que le constructeur n'est pas cité.<br>
 * 
 * @author Ibrahima Sory Bah, Malick Sarr Gaye, Ahouefa Zounon, Steven Martin
 */
public class ReadTheBook extends JPanel {
	
	/**
	 * Attribut représentant le besoin ou la demande de lecture du livre.
	 */
	private JButton readBook = new JButton("Lire le livre");
	
	/**
	 * Attribut représentant le panneau dans le quel est placé le texte du paragraphe.
	 */
	private JScrollPane sp = new JScrollPane();
	
	/**
	 * Attribut textP représentant le texte du paragraphe.
	 * 
	 * Attribut textChoices représentant la condition de choix des paragraphes choix de celui-ci.
	 */
	private JLabel textP = new JLabel(), textChoices = new JLabel();
	
	/**
	 * Attribut représentant la zone de saisi pour l'identifiant du paragraphe choix.
	 */
	private JTextField choice = new JTextField();
	
	/**
	 * Attributs représentant le panel gauche et droit qui sont ajoutés au "ReadBook".
	 */
	private JPanel leftSide, rightSide;
	
	/**
	 * Attribut représentant l'action d'avoir fini d'entrer l'identifiant d'un paragraphe choix.
	 */
	private JButton ok = new JButton("OK");
	
	/**
	 * Attribut représentant la liste de paragraphes.
	 */
	private ArrayList<Para> listP = new ArrayList<Para>();

	/**
	 * <b>Constructeur de la classe ReadTheBook</b>
	 * 
	 * @param listP
	 * 		La liste avec laquelle on initialise la liste de paragraphe lors de la création d'un ReadTheBook.
	 */
	public ReadTheBook(ArrayList<Para> listP) {

		super();
		this.setBackground(Color.WHITE);
		this.listP = listP;
		
		ReadTheBookControl rtbc = new ReadTheBookControl(this);
		this.readBook.addActionListener(rtbc);
		this.ok.addActionListener(rtbc);

		this.leftSide = new JPanel();
		this.leftSide.setAlignmentX(CENTER_ALIGNMENT);
		this.leftSide.setAlignmentY(CENTER_ALIGNMENT);
		this.leftSide.add(this.readBook);

		this.rightSide = new JPanel();
		this.rightSide.setBorder(BorderFactory.createTitledBorder("<html> <h2> Lecture d'un livre </h2> </html>"));
		this.rightSide.setLayout(new GridLayout(2,1));
		
		//this.rightSide.setLayout(new BoxLayout(this.rightSide, BoxLayout.PAGE_AXIS));
		
		JPanel essP = new JPanel();
		essP.setLayout(new GridLayout(1,2));
		essP.add(this.sp);
		essP.add(new JPanel());
		
		JPanel bottomSide = new JPanel();
		bottomSide.setLayout(new BorderLayout());
		
		JPanel botBotSide = new JPanel();
		botBotSide.setLayout(new GridLayout(1,2));
		botBotSide.add(this.choice);
		botBotSide.add(this.ok);
		
		bottomSide.add(this.textChoices, BorderLayout.CENTER);
		bottomSide.add(botBotSide, BorderLayout.SOUTH);
		
		this.rightSide.add(essP);
		this.rightSide.add(bottomSide);
		
		this.setLayout(new BorderLayout());		
		this.add(this.leftSide, BorderLayout.WEST);
		this.add(this.rightSide, BorderLayout.CENTER);

	}

	/**
	 * Méthode permettant d'accéder au JScrollPane "sp" de la classe ReadTheBook.
	 * 
	 * @return Une référence sur l'attribut sp.
	 */
	public JScrollPane getSp() {
		return this.sp;
	}

	/**
	 * Méthode permettant d'accéder au JButton "readBook" de la classe ReadTheBook.
	 * 
	 * @return Une référence sur l'attribut readBook.
	 */
	public JButton getReadBook() {
		return this.readBook;
	}

	/**
	 * Méthode permettant d'accéder au JLabel "getTextP" de la classe ReadTheBook.
	 * 
	 * @return Une référence sur l'attribut textP.
	 */
	public JLabel getTextP() {
		return this.textP;
	}

	/**
	 * Méthode permettant d'accéder au JLabel "textChoices" de la classe ReadTheBook.
	 * 
	 * @return Une référence sur l'attribut textChoices.
	 */
	public JLabel getTextChoices() {
		return this.textChoices;
	}

	/**
	 * Méthode permettant d'accéder au JTextField "choice" de la classe ReadTheBook.
	 * 
	 * @return Une référence sur l'attribut choice.
	 */
	public JTextField getChoice() {
		return this.choice;
	}

	/**
	 * Méthode permettant d'accéder au JPanel "leftSide" de la classe ReadTheBook.
	 * 
	 * @return Une référence sur l'attribut leftSide.
	 */
	public JPanel getLeftSide() {
		return this.leftSide;
	}

	/**
	 * Méthode permettant d'accéder au JPanel "rightSide" de la classe ReadTheBook.
	 * 
	 * @return Une référence sur l'attribut rightSide.
	 */
	public JPanel getRightSide() {
		return this.rightSide;
	}

	/**
	 * Méthode permettant d'accéder au JButton "ok" de la classe ReadTheBook.
	 * 
	 * @return Une référence sur l'attribut ok.
	 */
	public JButton getOk() {
		return this.ok;
	}

	/**
	 * Méthode permettant d'accéder au JScrollPane "listP" de la classe ReadTheBook.
	 * 
	 * @return Une référence sur l'attribut listP.
	 */
	public ArrayList<Para> getListP() {
		return this.listP;
	}

}
