package fr.sims_ldvelh.View;

import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.UIManager;
import javax.swing.plaf.nimbus.NimbusLookAndFeel;



/**
 * La classe s'occupe du déroulement du programme..<br>
 * 
 * @author Ibrahima Sory Bah, Malick Sarr Gaye, Ahouefa Zounon, Steven Martin
 */
public class Main_View {

	/**
	 * @param args
	 * 		Les paramètres passés à la classe lors de l'exécution du programme.
	 * 
	 * @throws Exception Déclenchée généralement lorsque la classe Main n'arrive pas à appliquer le look'n feel.
	 */
	public static void main(String[] args) throws Exception {

		// TODO Apply a look'n feel
		UIManager.setLookAndFeel(new NimbusLookAndFeel());

		// TODO La boîte de dialogue de départ
		JTextArea text = new JTextArea(
				"<html>Bienvenue dans SIMS, un éditeur de Livre Dont Vous êtes Le Heros (LVDELH). <br/>Vous devez : <br/>"
						+ "<ul> <li> Dans un premier temps, créer l'ensemble des paragraphes qui composeront votre livre. </li> "
						+ "<li> Dans un second temps, vous pourrez ajouter les différents choix résultants de chaque paragraphes. </li> "
						+ "<li> Et enfin, vous constituerez le graphe en ajoutant le noeud racine correspondant au paragraphe d'introduction. </li> </ul> <br/>"
						+ "Lorsque vous aurez terminer, veuillez cliquer sur le bouton <b> Créer un livre </b> situé tout au bas de la partie dédiée au graphe. <br/>"
						+ "Un fichier .JSON sera enregistré sur votre ordinateur. <br/> Nous pourrons vous assurer la création de ce fichier que si vous cliquez sur le bouton mentionné plus haut. <br/>"
						+ "<b> AVEZ-VOUS PRIS CONNAISSANCE DE TOUTES LES ETAPES ENONCEES CI-HAUT ? </b> </html>");

		JOptionPane startWlc = new JOptionPane(text.getText(), JOptionPane.QUESTION_MESSAGE, JOptionPane.YES_NO_OPTION,
				new ImageIcon("src/images/logo.png"));
		Integer wlc = null;

		// On crée la boite de dialogue correspondante :
		JDialog dialog = startWlc.createDialog(null, "SIMS-Bienvenue dans l'éditeur de LDVELH");
		dialog.setAlwaysOnTop(true); // On la met au dessus
		dialog.setVisible(true);
		dialog.dispose();

		// On traite la valeur reçue :
		Object selectedValue = startWlc.getValue();
		if (selectedValue == null)
			wlc = JOptionPane.CLOSED_OPTION;

		if (selectedValue instanceof Integer)
			wlc = ((Integer) selectedValue).intValue();

		if (wlc != JOptionPane.OK_OPTION) {

			JOptionPane endWlc = new JOptionPane("<html> <h2> AU REVOIR! </h2> <br/> Ce fut un plaisir. </html>",
					JOptionPane.OK_OPTION, JOptionPane.PLAIN_MESSAGE, new ImageIcon("src/images/logo.png"));
			JDialog dialog2 = endWlc.createDialog(null, "SIMS-Au revoir");
			dialog2.setAlwaysOnTop(true); // On la met au dessus
			dialog2.setVisible(true);
			dialog2.dispose();

			System.exit(0);
		}

		else {
			new BaseEditor();
		}

	}

}
