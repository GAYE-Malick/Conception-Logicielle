package fr.sims_ldvelh.View;

import java.awt.Color;

import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import fr.sims_ldvelh.Model.Para;

/**
 * La classe s'occupe de la présentation de la liste des oaragraphes créés au niveau de FirstEditor.<br>
 * 
 * Cette classe a pour attribut(s): 
 * <ul>
 * <li> Un DefaultListModel <b>model</b> de String qui est modèle sur lequel la ListParagraph s'appuie pour afficher ses éléments.</li>
 * </ul>
 * 
 * Cette classe a pour méthode(s): 
 * <ul>
 * <li> Un void <b>addPara</b> qui permet d'ajouter un paragraphe à la liste de paragraphes.</li>
 * <li> Un void <b>valueChanged</b> qui rend la liste non cliquable.</li>
 * </ul>
 * 
 * Veuillez noter que le constructeur n'est pas cité.<br>
 * 
 * @author Ibrahima Sory Bah, Malick Sarr Gaye, Ahouefa Zounon, Steven Martin
 */
public class ListParagraph extends JList<String> implements ListSelectionListener {

	/**
	 * Attribut représentant modèle que la ListParagraph utilise pour afficher ses éléments.
	 */
	private DefaultListModel<String> model = new DefaultListModel<String>();

	/**
	 * <b>Constructeur de ListParagraph</b>
	 */
	public ListParagraph() {

		this.setBackground(Color.WHITE);
		this.addListSelectionListener(this);

	}

	/**
	 * Méthode permettant d'ajouter un paragraphe au modèle d'affiche de la classe ListParagraph. Elle met aussi la liste à jour après l'ajout du paragraphe.
	 * 
	 * @param p
	 * 		Le paragraphe à ajouter.
	 */
	public void addPara(Para p) {

		this.model.addElement(p.getID() + " : " + p.getText().substring(0, 110) + "...");

		this.setModel(this.model);
		this.validate();
	}

	/**
	 * Méthode héritée de l'interface ListSelectionListener permettant de :<br>
	 * ne rien faire lors de la sélection d'un élément de la liste,<br>
	 * ne pas colorer la sélection non plus.<br>
	 * Elle rend la liste non cliquable.
	 * 
	 * @param lse
	 * 		L'action de sélectionner un élément de la liste.
	 */
	@Override
	public void valueChanged(ListSelectionEvent lse) {

		this.clearSelection();
		this.setFocusable(false);

	}

}
