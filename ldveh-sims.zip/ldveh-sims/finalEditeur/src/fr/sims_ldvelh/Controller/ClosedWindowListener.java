package fr.sims_ldvelh.Controller;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JOptionPane;

import fr.sims_ldvelh.View.BaseEditor;

/**
 * La classe s'occupe de toutes les actions opérées au niveau de l'éditeur de base "BaseEditor".<br>
 * Elle met ainsi la vue à jour en fonctions de ces modifications.<br>
 * 
 * Cette classe a pour attribut(s): 
 * <ul>
 * <li> Un BaseEditor <b>base</b> qui servira de référence sur l'élément BaseEditor qu'elle doit modifiée. </li>
 * </ul>
 * 
 * Cette classe a pour méthode(s): 
 * <ul>
 * <li> Un void <b>windowClosing</b> qui représente l'action à faire lorque l'on ferme la fenêtre base.</li>
 * </ul>
 * 
 * Veuillez noter que le constructeur n'est pas cité.<br>
 * 
 * @author Ibrahima Sory Bah, Malick Sarr Gaye, Ahouefa Zounon, Steven Martin
 */
public class ClosedWindowListener extends WindowAdapter {

	/**
	 * Attribut servant de référence sur le BaseEditor que la classe contrôle
	 */
	private BaseEditor base;

	/**
	 * <b>Constructeur de la classe ClosedWindowListener</b>
	 * 
	 * @param base
	 * 		L'élément BaseEditor à passer à l'attribut base de la classe ClosedWindowListener.
	 */
	public ClosedWindowListener(BaseEditor base) {
		this.base = base;
	}

	/**
	 * Méthode héritée de la classe mère WindowAdapter enclanchée lors de la fermeture de l'attribut base.
	 * 
	 * @param e
	 * 		Représentant un évenement sur la fenêtre.
	 */
	@Override
	public void windowClosing(WindowEvent e) {
		
		if (JOptionPane.showConfirmDialog(this.base, "Désirez-vous quitter l'application ?") == JOptionPane.YES_OPTION)
			System.exit(0);
	}

}
