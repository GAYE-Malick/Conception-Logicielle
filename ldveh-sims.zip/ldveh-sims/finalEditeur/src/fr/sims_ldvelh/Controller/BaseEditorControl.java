package fr.sims_ldvelh.Controller;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import fr.sims_ldvelh.View.BaseEditor;
import fr.sims_ldvelh.View.ReadTheBook;
import fr.sims_ldvelh.View.SecondEditor;
import fr.sims_ldvelh.View.ThirdEditor;

/**
 * La classe s'occupe de toutes les actions opérées au niveau de l'éditeur de base "BaseEditor".<br>
 * Elle met ainsi la vue à jour en fonctions de ces modifications.<br>
 * 
 * Cette classe a pour attribut(s): 
 * <ul>
 * <li> Un BaseEditor <b>base</b> qui servira de référence sur l'élément BaseEditor qu'elle doit modifiée. </li>
 * </ul>
 * 
 * Cette classe a pour méthode(s): 
 * <ul>
 * <li> Un void <b>actionPerformed</b> qui représente les modifications à apporter en fonction des différentes actions possibles sur l'attribut base.</li>
 * </ul>
 * 
 * Veuillez noter que le constructeur n'est pas cité.<br>
 * 
 * @author Ibrahima Sory Bah, Malick Sarr Gaye, Ahouefa Zounon, Steven Martin
 */
public class BaseEditorControl implements ActionListener {

	/**
	 * Attribut servant de référence sur le BaseEditor que la classe contrôle
	 */
	private BaseEditor base;

	/**
	 * <b>Constructeur de la classe BaseEditorControl</b>
	 * 
	 * @param bE
	 * 		L'élément BaseEditor à passer à l'attribut base de la classe BaseEditorControl.
	 */
	public BaseEditorControl(BaseEditor bE) {

		this.base = bE;
	}

	/**
	 * Méthode héritée de l'interface ActionListener enclanchée lors d'une action sur l'attribut base.
	 * 
	 * @param e
	 * 		Représentant l'évenement d'une action
	 */
	@Override
	public void actionPerformed(ActionEvent e) {

		if(e.getSource() == this.base.getOuvrir()) //Traitement effectué lorsqu'on clique sur ouvrir dans le menu
		{
			JOptionPane.showMessageDialog(this.base,
					"<html> <h3> Cette fonctionnalitée n'est pas encore disponible.<br>Nous sommes désolés du désagrément occasionné! </h3> </html>",
					"Editeur SIMS - Information", JOptionPane.INFORMATION_MESSAGE);
		}
		
		else if(e.getSource() == this.base.getQuitter()) //Traitement effectué lorsqu'on clique sur quitter dans le menu
		{
			if (JOptionPane.showConfirmDialog(this.base, "Désirez-vous quitter l'application ?") == JOptionPane.YES_OPTION)
				System.exit(0);
		}
		
		else if (e.getSource() == this.base.getFinishCreatePara()) { //Traitement effectué lorsque l'on clique sur le bouton "FinishCreatePara" d'un BaseEditor.

			if(this.base.getfE().getListPara().size() < 3)
			{
				JOptionPane.showMessageDialog(this.base, "Vous devez créer au moins tois paragraphes.",
						"Editeur SIMS - Warnings", JOptionPane.WARNING_MESSAGE);
			}
			
			else
			{
				int retour = JOptionPane.showConfirmDialog(this.base, "Avez-vous créer tous les paragraphes?",
						"Editeur SIMS - Confirmation", JOptionPane.YES_NO_OPTION);
				if (retour == JOptionPane.YES_OPTION) {
					JOptionPane.showMessageDialog(this.base,
							"Vous pouvez à présent ajouter les choix de chaque paragraphe et/ou faire des modifications.",
							"Editeur SIMS - Information", JOptionPane.INFORMATION_MESSAGE);
	
					this.base.setsE(new SecondEditor(this.base.getfE().getListPara()));
					this.base.getPane().removeAll();
					this.base.getPane().add(this.base.getsE(), BorderLayout.CENTER);
					this.base.getPane().add(this.base.getFinishModifPara(), BorderLayout.SOUTH);
					this.base.getPane().validate();
	
				}
			}
		}

		else if (e.getSource() == this.base.getFinishModifPara()) { //Traitement effectué lorsque l'on clique sur le bouton "FinishModifPara" d'un BaseEditor.

			int retour = JOptionPane.showConfirmDialog(this.base,
					"Avez-vous effectué les modifications que vous vouliez faire sur les paragraphes?",
					"Editeur SIMS - Confirmation", JOptionPane.YES_NO_OPTION);
			if (retour == JOptionPane.YES_OPTION) {
				JOptionPane.showMessageDialog(this.base, "Vous pouvez à présent créer la graphe.",
						"Editeur SIMS - Information", JOptionPane.INFORMATION_MESSAGE);
	
				this.base.settE(new ThirdEditor(this.base.getsE().getListPara()));
				this.base.getPane().removeAll();
				this.base.getPane().add(this.base.gettE(), BorderLayout.CENTER);
				this.base.getPane().add(this.base.getCreateBook(), BorderLayout.SOUTH);
				this.base.getPane().validate();
			}
		}

		else if (e.getSource() == this.base.getCreateBook()) { //Traitement effectué lorsque l'on clique sur le bouton "CreateBook" d'un BaseEditor.

			//this.base.gettE().getGraph().creerLivre();
			
			JOptionPane.showMessageDialog(this.base, "Vous pouvez à présent lire le livre si vous le voulez.",
					"Editeur SIMS - Information", JOptionPane.INFORMATION_MESSAGE);
			
			this.base.setRtb(new ReadTheBook(this.base.gettE().getDg().getListP()));
			this.base.getPane().removeAll();
			this.base.getPane().add(this.base.getRtb() , BorderLayout.CENTER);
			this.base.getRtb().getRightSide().setVisible(false);
			this.base.getPane().validate();

		}
	}

}
