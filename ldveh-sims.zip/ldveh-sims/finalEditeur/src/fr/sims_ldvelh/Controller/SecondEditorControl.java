package fr.sims_ldvelh.Controller;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JOptionPane;
import javax.swing.JPanel;

import fr.sims_ldvelh.Model.Para;
import fr.sims_ldvelh.View.DisplayListP;
import fr.sims_ldvelh.View.DisplayParagraph;
import fr.sims_ldvelh.View.EditParagraph;
import fr.sims_ldvelh.View.SecondEditor;

/**
 * La classe s'occupe de toutes les actions opérées au niveau de la classe gérant les modifications des paragraphes du livre "SecondEditor".<br>
 * Elle met ainsi la vue à jour en fonctions de ces modifications.<br>
 * Elle permet d'effectuer plusieurs modifications sur chauque paragraphe du livre.<br>
 * 
 * Cette classe a pour attribut(s): 
 * <ul>
 * <li> Un SecondEditor <b>sE</b> qui servira de référence sur l'élément SecondEditor qu'elle doit modifiée. </li>
 * <li> Un Integer <b>idt</b> qui permet de récupérer l'identifiant du paragraphe modifié s'il y a lieu de modifications. </li>
 * <li> Un Integer <b>indexParaSup</b> qui permet de récupérer l'identifiant du paragraphe à supprimer. </li>
 * </ul>
 * 
 * Cette classe a pour méthode(s): 
 * <ul>
 * <li> Un void <b>actionPerformed</b> qui représente les modifications à apporter en fonction des différentes actions possibles sur l'attribut sE.</li>
 * <li> Un ArrayList <b>toListInt</b> d'Integer qui permet d'avoir la liste des identifiants des paragraphes d'une liste de paragraphes.</li>
 * <li> Un void <b>updateSE</b> qui met à jour l'affichage de sE.</li>
 * <li> Un boolean <b>contain</b> qui vérifie si l'identifiant saisi correspond à celui d'un paragraphe de la liste de paragraphes.</li>
 * <li> Un void <b>modifierPara</b> qui applique les modifications faites au paragraphe.</li>
 * <li> Un void <b>updateListPara</b> qui met à jour la liste de paragraphes.</li>
 * </ul>
 * 
 * Veuillez noter que le constructeur n'est pas cité.<br>
 * 
 * @author Ibrahima Sory Bah, Malick Sarr Gaye, Ahouefa Zounon, Steven Martin
 */
public class SecondEditorControl implements ActionListener {

	/**
	 * Attribut servant de référence sur le SecondEditor que la classe contrôle.
	 */
	private SecondEditor sE;
	
	/**
	 * L'attribut <b>idt</b> permet de récupérer l'identifiant du paragraphe modifié s'il y a lieu de modifications.
	 * 
	 * L'attribut <b>indexParaSup</b> permet de récupérer l'identifiant du paragraphe à supprimer.
	 */
	private Integer idt, indexParaSup;

	/**
	 * <b>Constructeur de la classe SecondEditorControl</b>
	 * 
	 * @param sE
	 * 		L'élément SecondEditor à passer à l'attribut sE de la classe SecondEditorControl.
	 */
	public SecondEditorControl(SecondEditor sE) {

		this.sE = sE;
	}
	
	/**
	 *	Méthode héritée de l'interface ActionListener enclanchée lors d'une action sur l'attribut sE.
	 * 
	 * @param e
	 * 		Représentant l'évenement d'une action
	 * @throws NumberFormatException Déclanchée si les caractères saisis dans le champ de l'identifiant du paragraphe ne peuvent être convertis en entier lors de sa modification.
	 * 
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		
		if (e.getSource() == this.sE.getDlp().getDisp()) { //Afficher le paragraphe

			System.out.println("Voici qd on appuie sur afficher");
			this.sE.getDlp().getPara().afficherPara();
			this.updateSE();
		}

		else if (e.getSource() == this.sE.getDlp().getEditer()) { //Editer le paragraphe
			
			this.sE.setEp(new EditParagraph(this.sE.getDlp().getPara()));
			JPanel bottom = new JPanel();
			bottom.setLayout(new GridLayout(1, 2));

			this.sE.getAnnulerModifP().setVisible(true);
			this.sE.getFinishModifP().setVisible(true);

			bottom.add(this.sE.getAnnulerModifP());
			bottom.add(this.sE.getFinishModifP());

			this.sE.getRightSide().removeAll();
			this.sE.getRightSide().add(this.sE.getEp(), BorderLayout.CENTER);
			this.sE.getRightSide().add(bottom, BorderLayout.SOUTH);
			this.sE.getRightSide().validate();

		}

		else if (e.getSource() == this.sE.getDlp().getDel()) { //Supprimer le paragraphe
			
			this.sE.getListPara().remove(this.sE.getDlp().getIdSelectedItem());
			this.updateListPara();

		}

		else if (e.getSource() == this.sE.getDlp().getAddC()) { //Ajouter un choix
			
			ArrayList<Integer> listInt = this.toListInt(this.sE.getDlp().getList());
			int idlp = this.sE.getDlp().getIdSelectedItem();
			listInt.remove(idlp);
			
			//TODO Effacer l'id des paragraphes successeurs...
			for(int j = 0 ; j < listInt.size() ; j++)
			{
				for(int i = 0 ; i < this.sE.getDlp().getPara().getChoicesList().size() ; i++)
				{
					if(listInt.get(j) == this.sE.getDlp().getPara().getChoicesList().get(i).getID())
					{
						listInt.remove(j);
					}
				}
			}
			
			//La liste listInt est la liste des identifiants des paragraphes sans celui du paragraphe même et ceux des ses paragraphes choix.
			
			if(!listInt.isEmpty()) //Traitement effectué si la liste listInt n'est pas vide
			{
				int i = listInt.size();
				Integer[] listA = new Integer[i];
				for (int k = 0; k < i; k++) {
					listA[k] = listInt.get(k);
				}
				
				Integer idp = (Integer) JOptionPane.showInputDialog(this.sE.getDlp().getAddC(),
						"Veuillez sélectionner un choix du paragraphe!", "SIMS-Ajout de choix !",
						JOptionPane.QUESTION_MESSAGE, null, listA, listA[0]);
	
				for (int j = 0; j < this.sE.getDlp().getList().size(); j++) {
					if (idp == this.sE.getDlp().getList().get(j).getID()) {
						this.sE.getDlp().getPara().ajouterChoix(this.sE.getDlp().getList().get(j));
						break;
					}
				}
				
				this.updateSE();		
			}
			
			else
			{
				JOptionPane.showMessageDialog(this.sE.getRightSide(), "<html> Il n'y a plus de possibilitées d'ajouter de choix! </html>", "SIMS-Warning", JOptionPane.WARNING_MESSAGE);
				this.sE.getDlp().validate();
			}
			
		}

		else if (e.getSource() == this.sE.getDlp().getRemC()) { //Supprimer un choix
			
			if(!this.sE.getDlp().getPara().getChoicesList().isEmpty()) //Traitement effectué si la liste de choix du paragraphe n'est pas vide
			{
				int i = this.sE.getDlp().getPara().getChoicesList().size();
				Integer[] listR = new Integer[i];

				for (int k = 0; k < i; k++) {
					listR[k] = this.sE.getDlp().getPara().getChoicesList().get(k).getID();
				}
				
				Integer idp = (Integer) JOptionPane.showInputDialog(this.sE.getDlp().getAddC(),
						"Veuillez sélectionner un choix du paragraphe!", "SIMS-Ajout de choix !",
						JOptionPane.QUESTION_MESSAGE, null, listR, listR[0]);

				for (int j = 0; j < i; j++) {
					if (idp == this.sE.getDlp().getPara().getChoicesList().get(j).getID()) {
						this.sE.getDlp().getPara().retirerChoix(this.sE.getDlp().getPara().getChoicesList().get(j));
						break;
					}
				}
				
				this.sE.getDlp().setDp(new DisplayParagraph(this.sE.getDlp().getPara()));
				this.sE.getRightSide().add(this.sE.getDlp().getDp(), BorderLayout.CENTER);
				
			}
			
			else
			{
				JOptionPane.showMessageDialog(this.sE.getRightSide(), "<html> Le paragraphe ne possède aucun choix </html>", "SIMS-Warning", JOptionPane.WARNING_MESSAGE);
				this.sE.getRightSide().validate();
			}
			
		}

		else if (e.getSource() == this.sE.getDlp().getRemCT()) { //Supprimer tous les choix
			
			if(!this.sE.getDlp().getPara().getChoicesList().isEmpty()) //Traitement effectué si la liste de choix du paragraphe n'est pas vide
			{
				this.sE.getDlp().getPara().retirerTousLesChoix();
				this.updateSE();				
			}
			
			else
			{
				JOptionPane.showMessageDialog(this.sE.getRightSide(), "<html> Le paragraphe ne possède aucun choix </html>", "SIMS-Warning", JOptionPane.WARNING_MESSAGE);
				this.sE.getRightSide().validate();
			}
			
		}

		else if (e.getSource() == this.sE.getDlp().getAddW()) { //Ajouter un mot/pouvoir
			
			String word = (String) JOptionPane.showInputDialog(this.sE.getDlp().getAddW(),
					"<html> <b/> Entrez le pouvoir </html>\n", "Ajouter un pouvoir", JOptionPane.QUESTION_MESSAGE);
			this.sE.getDlp().getPara().ajouterWords(word);
			this.updateSE();
		}

		else if (e.getSource() == this.sE.getDlp().getRemW()) { //Supprimer un mot/pouvoir
			
			if(!this.sE.getDlp().getPara().getWords().isEmpty()) //Traitement effectué si la liste de mots/pouvoirs du paragraphe n'est pas vide
			{
				int i = this.sE.getDlp().getPara().getWords().size();
				String[] listW = new String[i];

				for (int k = 0; k < i; k++) {
					listW[k] = this.sE.getDlp().getPara().getWords().get(k);
				}

				String word = (String) JOptionPane.showInputDialog(this.sE.getDlp().getRemW(),
						"Veuillez sélectionner un choix du paragraphe!", "SIMS-Ajout de choix !",
						JOptionPane.QUESTION_MESSAGE, null, listW, listW[0]);
				this.sE.getDlp().getPara().retirerWords(word);
				this.updateSE();				
			}
			
			else
			{
				JOptionPane.showMessageDialog(this.sE.getRightSide(), "<html> Le paragraphe ne possède aucun mot/pouvoir </html>", "SIMS-Warning", JOptionPane.WARNING_MESSAGE);
				this.sE.getRightSide().validate();
			}
			
		}

		else if (e.getSource() == this.sE.getDlp().getRemWT()) { //Supprimer tous les mots/pouvoirs
			
			if(!this.sE.getDlp().getPara().getWords().isEmpty()) //Traitement effectué si la liste de mots/pouvoirs du paragraphe n'est pas vide
			{
				this.sE.getDlp().getPara().retirerTousLesWords();
				this.updateSE();				
			}
			
			else
			{
				JOptionPane.showMessageDialog(this.sE.getRightSide(), "<html> Le paragraphe ne possède aucun mot/pouvoir </html>", "SIMS-Warning", JOptionPane.WARNING_MESSAGE);
				this.sE.getRightSide().validate();
			}
			
		}

		else if (e.getSource() == this.sE.getAnnulerModifP()) { //Annuler les changements faits lors de la modification du paragraphe
			
			this.updateSE();
		}

		else if (e.getSource() == this.sE.getFinishModifP()) { //Confirmer les changements faits lors de la modification du paragraphe

			try {
				this.idt = Integer.parseInt(this.sE.getEp().getId().getText());
			} catch (Exception excep) {
				JOptionPane.showMessageDialog(this.sE,
						"<html> La valeur de l'id doit être un entier. <br/> Veuillez saisir un entier </html>",
						"SIMS-Erreur", JOptionPane.ERROR_MESSAGE);
			}

			if (this.idt != null) { //Traitement effectué si l'identifiant n'est pas nul
				
				if (this.contain(this.sE.getListPara(), this.idt)) { //Traitement effectué si l'identifiant correspond à celui d'un paragraphe de la liste des paragraphes.
					
					String opt[] = { "Supprimer le paragraphe de même id existant", "Annuler" };

					int ret = JOptionPane.showOptionDialog(this.sE.getEp(),
							"<html> Un paragraphe ayant le même id existe déjà <br/>Que faire ? </html>",
							"SIMS-Warning", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE, null, opt, opt[1]);

					if (ret == 0) // On supprime le paragraphe
					{
						this.sE.getListPara().remove((int)this.indexParaSup);
						this.updateListPara();
					}
					
				}

				else 
				{
					this.modifierPara();
				}
			}

		}

	}

	/**
	 * Méthode permettant d'avoir la liste des identifiants des paragraphes d'une liste de paragraphes.
	 * 
	 * @param listP
	 * 		La liste de paragraphes dont on doit récupérer les id
	 * @return
	 */
	public ArrayList<Integer> toListInt(ArrayList<Para> listP) {
		
		ArrayList<Integer> listInt = new ArrayList<Integer>();
		for(int i = 0 ; i < listP.size() ; i++)
		{
			listInt.add(listP.get(i).getID());
		}
		
		return listInt;
	}
	
	/**
	 * Méthode mettant à jour l'affichage de sE.
	 */
	public void updateSE() {

		this.sE.getRightSide().removeAll();
		this.sE.getDlp().setDp(new DisplayParagraph(this.sE.getDlp().getPara()));
		this.sE.getRightSide().add(this.sE.getDlp().getDp(), BorderLayout.CENTER);
		this.sE.getRightSide().validate();
	}

	/**
	 * Méthode permettant de vérifier si un identifiant correspond à celui d'un paragraphe d'une liste de paragraphes.
	 * 
	 * @param list
	 * 		La liste de paragraphe dans laquelle on doit rechercher un paragraphe de même identifiant que x
	 * @param x
	 * 		L'identifiant à rechercher
	 * @return Un booléen étant à <code>true</code> si l'identifiant correspond à celui d'un paragraphe de la liste de paragraphes sinon à <code>false</code>.
	 */
	public boolean contain(ArrayList<Para> list, int x) {

		boolean inList = false;

		int idlp = this.sE.getDlp().getIdSelectedItem();
		ArrayList<Integer> idp = new ArrayList<Integer>();
		for (int i = 0; i < list.size(); i++) {
			idp.add(list.get(i).getID());
		}

		idp.remove(idlp);

		for (int i = 0; i < idp.size(); i++) {
			if (x == idp.get(i)) {
				this.indexParaSup = i;
				inList = true;
				break;
			}
		}

		return inList;
	}

	/**
	 * Méthode permettant de modifier un paragraphe et de le mettre à jour.<br>
	 * Elle met aussi à jour l'affichage de sE.
	 */
	public void modifierPara() {

		this.sE.getDlp().getPara().setID(this.idt);
		this.sE.getDlp().getPara().setText(this.sE.getEp().getText().getText());
		this.sE.getDlp().getPara().mettreUnchoiceText(this.sE.getEp().getTextC().getText());
		this.sE.getDlp().getPara().setAlternate_choices(this.sE.getEp().getaC().isSelected());
		this.sE.getDlp().getPara().setTrim_choices(this.sE.getEp().gettC().isSelected());

		int id = this.sE.getDlp().getIdSelectedItem();

		this.sE.getListPara().set(id, this.sE.getDlp().getPara());

		String newVal = this.sE.getDlp().getPara().getID() + " : "
				+ this.sE.getDlp().getPara().getText().substring(0, 110) + "...";

		this.sE.getDlp().getModel().setElementAt(newVal, id);
		this.sE.getDlp().validate();
		this.sE.getSp().validate();

		this.updateSE();

	}

	/**
	 * Méthode mettant à jour la liste de paragraphes et aussi l'affichage de sE.
	 */
	public void updateListPara() {

		this.sE.getDlp().setList(this.sE.getListPara());

		this.sE.setDlp(new DisplayListP(this.sE));
		this.sE.getSp().setViewportView(this.sE.getDlp());
		this.sE.getSp().validate();
		this.sE.getRightSide().removeAll();
		this.sE.getRightSide().validate();
		this.sE.validate();
	}

}
