package fr.sims_ldvelh.Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import fr.sims_ldvelh.Model.Para;
import fr.sims_ldvelh.View.ReadTheBook;

/**
 * La classe s'occupe de toutes les actions opérées au niveau de la classe gérant la lecture du livre "ReadTheBook".<br>
 * Elle met ainsi la vue à jour en fonctions de ces modifications.<br>
 * Elle permet de lire le livre crée.<br>
 * 
 * Cette classe a pour attribut(s): 
 * <ul>
 * <li> Un ReadTheBook <b>rtb</b> qui servira de référence sur l'élément ReadTheBook qu'elle doit modifiée. </li>
 * <li> Un para <b>p</b> qui permet de récupérer le paragraphe choix choisi. </li>
 * <li> Un para <b>currentPara</b> qui représente le paragraphe courant. </li>
 * </ul>
 * 
 * Cette classe a pour méthode(s): 
 * <ul>
 * <li> Un void <b>actionPerformed</b> qui représente les modifications à apporter en fonction des différentes actions possibles sur l'attribut fE.</li>
 * <li> Un void <b>displayPara</b> qui affiche un paragraphe.</li>
 * <li> Un boolean <b>research</b> qui vérifie si l'identifiant saisi correspond à celui d'un paragraphe de la liste de paragraphes.</li>
 * <li> Un boolean <b>inParaChoiceList</b> qui vérifie si l'identifiant saisi correspond à celui d'un paragraphe choix du paragraphe courant.</li>
 * </ul>
 * 
 * Veuillez noter que le constructeur n'est pas cité.<br>
 * 
 * @author Ibrahima Sory Bah, Malick Sarr Gaye, Ahouefa Zounon, Steven Martin
 */
public class ReadTheBookControl implements ActionListener{

	/**
	 * Attribut servant de référence sur le ReadTheBook que la classe contrôle.
	 */
	private ReadTheBook rtb;
	
	/**
	 * L'attribut <b>p</b> permet de récupérer le paragraphe à l'identifiant correspondant à celui saisi lors du choix du paragraphe vers lequel l'on veut aller.<br>
	 * Il appartient à la liste de choix du paragraphe courant.<br>
	 * 
	 * L'attribut <b>currentPara</b> permet de récupérer le paragraphe correspondant à l'identifiant saisi lors du choix du paragraphe vers lequel l'on veut aller.
	 */
	private Para p, currentPara;
	
	/**
	 * <b>Constructeur de la classe ReadTheBookControl</b>
	 * 
	 * @param rtb
	 * 		L'élément ReadTheBook à passer à l'attribut rtb de la classe ReadTheBookControl.
	 */
	public ReadTheBookControl(ReadTheBook rtb) {
		
		this.rtb = rtb;
		
	}

	/**
	 *	Méthode héritée de l'interface ActionListener enclanchée lors d'une action sur l'attribut rtb.
	 * 
	 * @param e
	 * 		Représentant l'évenement d'une action
	 * @throws NumberFormatException Déclanchée si les caractères saisis dans le champ de l'identifiant du paragraphe choix ne peuvent être convertis en entier.
	 * 
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
		if(e.getSource() == this.rtb.getReadBook()) //Traitement effectué si l'on clique sur le bouton "readBook" de la classe ReadTheBook.
		{
			this.rtb.getReadBook().setEnabled(false);
			this.displayPara(this.rtb.getListP().get(0));

			this.rtb.getRightSide().validate();
			this.rtb.getRightSide().setVisible(true);
			
		}
		
		else if(e.getSource() == this.rtb.getOk()) //Traitement effectué si l'on clique sur le bouton "ok" de la classe ReadTheBook.
		{			
			Integer idt = null;
			try {
				idt = Integer.parseInt(this.rtb.getChoice().getText());
			} catch (Exception excep) {
				JOptionPane.showMessageDialog(this.rtb.getRightSide(),
						"<html> La valeur du numéro doit être un entier. <br/> Veuillez saisir un entier </html>",
						"SIMS-Erreur", JOptionPane.ERROR_MESSAGE);
			}

			if (idt != null) { //Traitement effectué si l'identifiant n'est pas nul.
				
				if(this.research(idt) && this.inParaChoiceList(idt)) //Traitement effectué si l'identifiant correspond à celui d'un paragraphe de la liste de paragraphes et aussi à celui d'un paragraphe de la liste de choix du paragraphe courant. 
				{
					this.rtb.getRightSide().setVisible(false);
					this.displayPara(this.p);
					this.rtb.getRightSide().setVisible(true);
					this.rtb.getRightSide().validate();
					this.rtb.validate();
				}
				
				else
				{
					if(!this.research(idt)) //Traitement effectué si le paragraphe n'est pas dans la liste des paragraphes.
					{	
						JOptionPane.showMessageDialog(this.rtb.getRightSide(),
							"<html> Le paramètre n'exite pas. <br/> Veuillez saisir un entier parmi les choix proposés. </html>",
							"SIMS-Erreur", JOptionPane.ERROR_MESSAGE);
					}
					
					else if(!this.inParaChoiceList(idt)) //Traitement effectué si le paragraphe n'est pas dans la liste des paragraphes choix du paragraphe courant.
					{	
						JOptionPane.showMessageDialog(this.rtb.getRightSide(),
							"<html> Le paramètre ne fait pas partie de la liste de choix du paragraphe. <br/> Veuillez saisir un entier parmi les choix proposés. </html>",
							"SIMS-Erreur", JOptionPane.ERROR_MESSAGE);
					}
				}
			}
		}
	}
	
	/**
	 * Méthode qui affiche un paragraphe lors de sa lecture.<br>
	 * Elle met aussi à jour le paragraphe courant.<br>
	 * 
	 * @param A
	 * 		Le paragraphe à afficher et le nouveau paragraphe courant.
	 */
	public void displayPara(Para A) {
		
		this.currentPara = A;
		
		String textC = new String();
		
		for(int i = 0 ; i < A.getChoicesList().size() ; i++)
		{
			textC += "Si " + A.getChoicesList().get(i).getChoiceText() + " Alors saisissez le nombre: " + A.getChoicesList().get(i).getID() + "<br>";
			textC += System.lineSeparator();
		}
		
		
		
		if(A.getChoicesList().isEmpty()) //
		{
			textC = "<html> <h4> " + textC + " </h4> </html>";
		}
		
		else
		{
			textC = "<html> <h4> " + textC + " <br> Veuillez saisir le numéro de votre choix! </h4> </html>";
		}
		
		this.rtb.getTextP().setText(A.getText());
		JPanel textEssai = new JPanel();
		textEssai.setLayout(new BoxLayout(textEssai, BoxLayout.PAGE_AXIS));
		//textEssai.setSize(new Dimension(500,800));
		textEssai.add(new JLabel("<html> <h4> Texte </h4> <br/> <br/> <p>" + this.rtb.getTextP().getText()));
		
		this.rtb.getSp().setBorder(BorderFactory.createTitledBorder("<html> <h4> Texte </h4> </html>"));
		this.rtb.getSp().setViewportView(this.rtb.getTextP());
		this.rtb.getTextChoices().setText(textC);
		
	}
	
	/**
	 * Méthode vérifiant si l'identifiant correspond à celui d'un paragraphe de la liste générale de paragraphes.<br>
	 * 
	 * @param x
	 * 		L'identifiant à rechercher.
	 * @return Un booléen étant à <code>true</code> si l'identifiant correspond à celui d'un paragraphe de la liste de paragraphes sinon à <code>false</code>.
	 */
	public boolean research(int x) {
		
		boolean inList = false;
		
		for(int i = 0 ; i < this.rtb.getListP().size() ; i++)
		{
			if(x == this.rtb.getListP().get(i).getID())
			{
				inList = true;
				break;
			}
			
		}
		
		return inList;
	}
	
	/**
	 * Méthode vérifiant si l'identifiant correspond à celui d'un paragraphe choix de la liste des paragraphes choix du paragraphe courant.<br>
	 * 
	 * @param x
	 * 		L'identifiant à vérifier
	 * @return Un booléen étant à <code>true</code> si l'identifiant correspond à celui d'un paragraphe choix du paragraphe courant sinon à <code>false</code>.
	 */
	public boolean inParaChoiceList(int x) {
		
		boolean inList = false;
		
		for(int i = 0 ; i < this.currentPara.getChoicesList().size() ; i++)
		{
			if(x == this.currentPara.getChoicesList().get(i).getID())
			{
				inList = true;
				this.p = this.currentPara.getChoicesList().get(i);
				break;
			}
			
		}
		
		return inList;
	}
	
}
