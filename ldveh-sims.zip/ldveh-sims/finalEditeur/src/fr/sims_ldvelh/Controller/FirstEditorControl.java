package fr.sims_ldvelh.Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import fr.sims_ldvelh.Model.Para;
import fr.sims_ldvelh.View.FirstEditor;

/**
 * La classe s'occupe de toutes les actions opérées au niveau de la classe gérant la création des paragraphes du livre "FirstEditor".<br>
 * Elle met ainsi la vue à jour en fonctions de ces modifications.<br>
 * Elle permet aussi de créer un paragraphe et de mettre à jour la liste de paragraphes.<br>
 * 
 * Cette classe a pour attribut(s): 
 * <ul>
 * <li> Un FirstEditor <b>fE</b> qui servira de référence sur l'élément FirstEditor qu'elle doit modifiée. </li>
 * <li> Un Integer <b>idt</b> qui permet de récupérer l'entier saisi comme identifiant d'un paragraphe. </li>
 * </ul>
 * 
 * Cette classe a pour méthode(s): 
 * <ul>
 * <li> Un void <b>actionPerformed</b> qui représente les modifications à apporter en fonction des différentes actions possibles sur l'attribut fE.</li>
 * <li> Un boolean <b>contain</b> qui vérifie si un paragraphe appartient à la liste de paragraphes.</li>
 * <li> Un void <b>addPara</b> qui ajoute un paragraphe à la liste de paragraphes.</li>
 * </ul>
 * 
 * Veuillez noter que le constructeur n'est pas cité.<br>
 * 
 * @author Ibrahima Sory Bah, Malick Sarr Gaye, Ahouefa Zounon, Steven Martin
 */
public class FirstEditorControl implements ActionListener {

	/**
	 * Attribut servant de référence sur le FirstEditor que la classe contrôle
	 */
	private FirstEditor fE;
	
	/**
	 * Attribut représentant l'entier saisi comme identifiant d'un paragraphe.
	 */
	private Integer idt = null;

	/**
	 * <b>Constructeur de la classe FirstEditorControl</b>
	 * 
	 * @param f
	 * 		L'élément FirstEditor à passer à l'attribut fE de la classe FirstEditorControl.
	 */
	public FirstEditorControl(FirstEditor f) {

		this.fE = f;
	}

	/**
	 * Méthode héritée de l'interface ActionListener enclanchée lors d'une action sur l'attribut fE.
	 * 
	 * @param e
	 * 		Représentant l'évenement d'une action
	 * @throws NumberFormatException Déclanchée si les caractères saisis dans le champ de l'identifiant ne peuvent être convertis en entier.
	 */
	@Override
	public void actionPerformed(ActionEvent e) {

		try { //On essaie de convertir les caractères saisis en entier
			
			this.idt = Integer.parseInt(this.fE.getCp().getId().getText());
		} 
		
		catch (Exception excep) { //Traitement effectué si on n'y arrive pas
			
			JOptionPane.showMessageDialog(this.fE, "<html> La valeur de l'id doit être un entier. <br> Veuillez saisir un entier </html>",	"SIMS-Erreur", JOptionPane.ERROR_MESSAGE);
		}

		if (this.idt != null) { //Traitement effectué si l'identifiant n'est pas nul
			
			if (this.fE.getListPara().isEmpty()) { //Traitement effectué si la liste de paragraphes est vide
				this.addPara();
			}

			else 
			{
				
				if (this.contain(this.fE.getListPara(), this.idt)) { //Traitement effectué si la liste de paragraphes contient un paragraphe de même identifiant
					
					JOptionPane.showMessageDialog(this.fE, "<html> Un paragraphe ayant le même id existe déjà. <br> Veuillez saisir un nouveau paragraphe </html>", "SIMS-Warning", JOptionPane.WARNING_MESSAGE);
				}

				else 
				{
					this.addPara();
				}
			}
		}

	}

	/**
	 * Méthode vérifiant si l'identifiant saisi correspond à celui d'un paragraphe existant dans la liste de paragraphes
	 * 
	 * @param list
	 * 		La liste de paragraphes
	 * @param x
	 * 		L'identifiant à vérifier
	 * @return Un booléen étant à <code>true</code> si l'identifiant correspond à un paragraphe de la liste sinon à <code>false</code>.
	 */
	public boolean contain(ArrayList<Para> list, int x) {

		boolean inList = false;

		for (int i = 0; i < list.size(); i++) {
			if (x == list.get(i).getID()) {
				inList = true;
				break;
			}
		}

		return inList;
	}

	/**
	 * Méthode permettant de créer un paragraphe en utilisant les différents champs de fE.<br>
	 * Elle met aussi à jour la liste de paragraphes et la partie de création de paragraphe.
	 */
	public void addPara() {

		Para p = new Para(this.idt, this.fE.getCp().getText().getText());
		p.mettreUnchoiceText(this.fE.getCp().getTextC().getText());

		if (this.fE.getCp().getaC().isSelected() == true) {
			p.setAlternate_choices(true);
			p.setTrim_choices(false);
		}

		else if (this.fE.getCp().gettC().isSelected() == true) {
			p.setAlternate_choices(false);
			p.setTrim_choices(true);
		}

		else {
			p.setAlternate_choices(false);
			p.setTrim_choices(false);
		}

		this.fE.getListPara().add(p);
		this.fE.getLp().addPara(p);
		this.fE.validate();
	}

}
