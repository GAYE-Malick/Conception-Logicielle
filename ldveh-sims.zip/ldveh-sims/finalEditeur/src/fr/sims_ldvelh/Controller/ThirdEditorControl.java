package fr.sims_ldvelh.Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import fr.sims_ldvelh.Model.Graphe;
import fr.sims_ldvelh.Model.Para;
import fr.sims_ldvelh.View.ThirdEditor;

/**
 * La classe s'occupe de toutes les actions opérées au niveau de la classe gérant le graphe du livre "ThirdEditor".<br>
 * Elle met ainsi la vue à jour en fonctions de ces modifications.<br>
 * Elle permet d'ajouter le paragraphe racine du graphe du livre.<br>
 * 
 * Cette classe a pour attribut(s): 
 * <ul>
 * <li> Un ThirdEditor <b>tE</b> qui servira de référence sur l'élément ThirdEditor qu'elle doit modifiée. </li>
 * <li> Un Graphe <b>graph</b> qui représente le graphe du livre. </li>
 * </ul>
 * 
 * Cette classe a pour méthode(s): 
 * <ul>
 * <li> Un void <b>actionPerformed</b> qui représente les modifications à apporter en fonction des différentes actions possibles sur l'attribut tE.</li>
 * <li> Un Graphe <b>getGraph</b> d'Integer qui permet de retourner le graphe.</li>
 * <li> Un boolean <b>contain</b> qui vérifie si un paragraphe appartient déjà au graphe.</li>
 * <li> Un void <b>createGraph</b> qui met à jour l'affichage de sE.</li>
 * </ul>
 * 
 * Veuillez noter que le constructeur n'est pas cité.<br>
 * 
 * @author Ibrahima Sory Bah, Malick Sarr Gaye, Ahouefa Zounon, Steven Martin
 */
public class ThirdEditorControl implements ActionListener {

	/**
	 * Attribut servant de référence sur le ThirdEditor que la classe contrôle.
	 */
	private ThirdEditor tE;
	
	/**
	 * Attribut représentant le graphe du livre.
	 */
	private Graphe graph;

	/**
	 * <b>Constructeur de la classe ThirdEditorControl</b>
	 * 
	 * @param tE
	 * 		L'élément ThirdEditor à passer à l'attribut tE de la classe ThirdEditorControl.
	 */
	public ThirdEditorControl(ThirdEditor tE) {

		this.tE = tE;

	}

	/**
	 * Méthode héritée de l'interface ActionListener enclanchée lors d'une action sur l'attribut tE.
	 * 
	 * @param e
	 * 		Représentant l'évenement d'une action
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

		if (e.getSource() == this.tE.getAddRacine()) { //Traitement effectué si l'on clique sur le bouton "addRacine" de la classe ThidEditor.
			
			int i = this.tE.getList().size();
			Integer[] listA = new Integer[i];
			for (int k = 0; k < i; k++) {
				listA[k] = this.tE.getList().get(k).getID();
			}

			Integer idp = (Integer) JOptionPane.showInputDialog(this.tE,
					"Veuillez sélectionner l'id du paragraphe racine!", "SIMS-Sélection Para Racine !",
					JOptionPane.QUESTION_MESSAGE, null, listA, listA[0]);

			for (int j = 0; j < this.tE.getList().size(); j++) {
				if (idp == this.tE.getList().get(j).getID()) {
					this.tE.getDg().setP(this.tE.getList().get(j));
					break;
				}
			}

			this.graph = new Graphe();
			this.createGraph(this.tE.getDg().getP());
			this.tE.setGraph(this.graph);

			this.tE.getAddRacine().setEnabled(false);
			this.tE.getDg().repaint();
			this.tE.getSp().setViewportView(this.tE.getDg());
			this.tE.getSp().validate();
			this.tE.validate();

		}

		else if (e.getSource() == this.tE.getRetNoeud()) { //Traitement effectué si l'on clique sur le bouton "retNoeud" de la classe ThidEditor.

		}
	}

	/**
	 * Méthode permettant d'avoir accès au graphe.
	 * 
	 * @return Le graphe du livre.
	 */
	public Graphe getGraph() {
		return this.graph;
	}
	
	/**
	 * Méthode vérifiant si un paragraphe appartient déjà au graphe.
	 * 
	 * @param p
	 * 		Le paragraphe à chercher dans le graphe
	 * @return Un booléen étant à <code>true</code> si le paragraphe appartient au grape sinon à <code>false</code>.
	 */
	public boolean contain(Para p) {
		
		boolean inList = false;
		
			for(int i = 0 ; i < this.graph.getAll().size() ; i++)
			{
				if(p.getID() == this.graph.getAll().get(i).getID())
				{
					inList = true;
					break;
				}
			}
		
		return inList;
	}

	/**
	 * Méthode permettant de créer le graphe à partir d'un paragraphe.
	 * 
	 * @param p
	 * 		Le paragraphe parent.
	 */
	public void createGraph(Para p) {

		if (!this.contain(p)) //Vérifie si le para n'est pas déjà dans le graphe
		{
			this.graph.ajouterUnNoeud(p);
		
			if (!p.getChoicesList().isEmpty()) //Vérifie que sa liste de choix n'est pas vide
			{
				for (int i = 0; i < p.getChoicesList().size(); i++) 
				{
					this.createGraph(p.getChoicesList().get(i));
				}
			}
		}

	}

}
