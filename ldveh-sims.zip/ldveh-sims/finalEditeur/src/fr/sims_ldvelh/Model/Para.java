package fr.sims_ldvelh.Model;

import java.util.ArrayList; // import the ArrayList class
import java.util.HashMap; // import the HashMap class

/**
 * La classe permet de créer un pargraphe et gère toutes les modifications à faire sur le paragraphe.<br>
 * 
 * Cette classe a pour attribut(s): 
 * <ul>
 * <li> Un Integer <b>id</b> qui représente l'identifiant du paragraphe. </li>
 * <li> Un String <b>text</b> qui représente le texte du paragraphe. </li>
 * <li> Un String <b>choiceText</b> qui représente la condition de choix du paragraphe. </li>
 * <li> Un boolean <b>alternate_choices</b> qui représente le type de choix "alternative". </li>
 * <li> Un boolean <b>trim_choices</b> qui représente le type de choix "trim". </li>
 * <li> Un HAshMap <b>choix</b> avec comme Keys des Integer et Values des Para. Il représente tous les paragraphes choix du paragraphe. </li>
 * <li> Un ArrayList <b>words</b> de String qui représente les mots/pouvoirs du paragraphe. </li>
 * <li> Un ArrayList <b>choicesList</b> de Para qui représente la liste simple des paragraphes choix du paragraphe. </li>
 * <li> Un int <b>posX</b> qui représente la position X du paragraphe pour la disposition dans le graphe au niveau de l'affichage. </li>
 * <li> Un int <b>posY</b> qui représente la position Y du paragraphe pour la disposition dans le graphe au niveau de l'affichage. </li>
 * </ul>
 * 
 * Cette classe a pour méthode(s): 
 * <ul>
 * <li> Un void <b>ajouterChoix</b> qui ajoute un paragraphe choix à la liste de paragraphes choix du paragraphe.</li>
 * <li> Un void <b>ajouterWords</b> qui ajoute un mot/pouvoir à la liste de mots/pouvoirs du paragraphe.</li>
 * <li> Un void <b>mettreUnChoiceText</b> qui permet de changer la condition de choix du paragraphe.</li>
 * <li> Un void <b>retirerChoix</b> qui retire un paragraphe choix de la liste de paragraphes choix du paragraphe.</li>
 * <li> Un void <b>retirerTousLesChoix</b> qui retire tous les paragraphes choix de la liste des paragraphes choix du paragraphe.</li>
 * <li> Un void <b>afficherPara</b> qui permet d'afficher un paragraphe.</li>
 * <li> Un Integer <b>getID</b> qui renvoie la valeur de l'identifiant du paragraphe.</li>
 * <li> Un String <b>getText</b> qui renvoie le texte du paragraphe.</li>
 * <li> Un boolean <b>getAlternate_choices</b> qui retourne la valeur de l'attribut alternate_choices du paragraphe.</li>
 * <li> Un String <b>getChoiceText</b> qui retourne la condition de choix du paragraphe.</li>
 * <li> Un HashMap <b>getChoix</b> qui retourne tous les paragraphes choix du paragraphe avec comme Keys des Integer et Values des Para.</li>
 * <li> Un ArrayList <b>getWords</b> de String qui retourne tous les mots/pouvoirs du paragraphe.</li>
 * <li> Un void <b>setID</b> qui permet de changer la valeur de l'identifiant du paragraphe.</li>
 * <li> Un void <b>setText</b> qui permet de changer le texte du paragraphe.</li>
 * <li> Un void <b>retirerWords</b> qui supprimer un mot/pouvoirs de la liste des mots/pouvoirs du paragraphe.</li>
 * <li> Un void <b>retirerTousLesWords</b> qui supprime tous les mots/pouvoirs de la liste des mots/pouvoirs du paragraphe..</li>
 * <li> Un ArrayList <b>getChoicesList</b> de Para qui rentourne l'ensemble des paragraphes choix du paragraphe.</li>
 * <li> Un boolean <b>isTrim_choices</b> qui retourne la valeur de l'attribut trim_choices du paragraphe.</li>
 * <li> Un void <b>setAlternate_choices</b> qui permet de modifier la valeur de l'attribut alternate_choices du paragraphe.</li>
 * <li> Un void <b>setTrim_choices</b> qui permet de modifier la valeur de l'attribut trim_choices du paragraphe.</li>
 * <li> Un int <b>getPosX</b> qui retourne la valeur de la position du paragraphe sur l'axe horizontal x.</li>
 * <li> Un int <b>getPosY</b> qui retourne la valeur de la position du paragraphe sur l'axe vertical y.</li>
 * <li> Un int <b>setPosX</b> qui permet de modifier la valeur de l'attribut posX du paragraphe.</li>
 * <li> Un int <b>setPosY</b> qui permet de modifier la valeur de l'attribut posY du paragraphe.</li>
 * </ul>
 * 
 * Veuillez noter que le constructeur n'est pas cité.<br>
 * 
 * @author Ibrahima Sory Bah, Malick Sarr Gaye, Ahouefa Zounon, Steven Martin
 */
public class Para {

	/**
	 * Attribut représentant l'identifiant du paragraphe.
	 */
	private Integer id;
	
	/**
	 * L'attribut text représente le texte du paragraphe.<br>
	 * 
	 * L'attribut choiceText représente la condition de choix du paragraphe.
	 */
	private String text, choiceText;
	
	/**
	 * Les attributs alternate_choices et trim_choices représentent le type de choix du paragraphe.
	 */
	private boolean alternate_choices, trim_choices;
	
	/**
	 * Attribut représentant la liste des paragraphes choix du paragraphe.
	 */
	private HashMap<Integer, Para> choix;
	
	/**
	 * Attribut représentant la liste des mots/pouvoirs du paragraphe.
	 */
	private ArrayList<String> words;

// Attributs add par Sharonn
	
	/**
	 * Attribut représentant la liste simple des paragraphes choix du paragraphe.
	 */
	private ArrayList<Para> choicesList;
	
	/**
	 * L'attribut posX représente la position X du paragraphe pour la disposition dans le graphe au niveau de l'affichage.<br>
	 * 
	 * L'attribut posY représente la position Y du paragraphe pour la disposition dans le graphe au niveau de l'affichage.
	 */
	private int posX, posY;
//Fin Attributs add par Sharonn

	/**
	 * <b>Constructeur de la classe Para</b>
	 * 
	 * @param id
	 * 		L'identifiant du paragraphe.
	 * @param text
	 * 		Le texte du paragraphe.
	 */
	public Para(Integer id, String text) {

		this.id = id;
		this.text = text;
		this.choix = new HashMap<Integer, Para>();
		this.words = new ArrayList<String>();
		
		// Sharonn
		this.choicesList = new ArrayList<Para>();
		this.posX = 0;
		this.posY = 0;
	}

	/**
	 * Méthode permettant d'ajouter un paragraphe comme choix du paragraphe.
	 * 
	 * @param p2
	 * 		Le paragraphe à ajouter comme choix du paragraphe.
	 */
	public void ajouterChoix(Para p2) {

		if (p2 != null) {
			this.choix.put(p2.getID(), p2);
			this.choicesList.add(p2);
		}
	}

	/**
	 * Méthode permettant d'ajouter un mot/pouvoir à ajouter à la liste de mots/pouvoirs du paragraphes.
	 * 
	 * @param w
	 * 		Le mot/pouvoir à ajouter à la liste de mots/pouvoirs du paragraphes.
	 */
	public void ajouterWords(String w) {

		this.words.add(w);
	}

	/**
	 * Méthode permettant de changer la condition de choix du paragraphe.
	 * 
	 * @param t
	 * 		La nouvelle condition de choix du paragraphe.
	 */
	public void mettreUnchoiceText(String t) {

		this.choiceText = t;
	}

	/**
	 * Méthode permettant de retirer un choix de la liste de paragraphes choix du paragraphe.
	 * 
	 * @param p2
	 * 		Le paragraphe à retirer.
	 */
	public void retirerChoix(Para p2) {

		if (p2 != null) {
			this.choix.remove(p2.getID());
			this.choicesList.remove(p2);
		}
	}

	/**
	 * Méthode permettant de retirer tous les choix du paragraphe.
	 */
	public void retirerTousLesChoix() {

		this.choix.clear();
		this.choicesList.clear();
	}

	/**
	 * Méthode permettant d'afficher un paragraphe en mode console.
	 */
	public void afficherPara() {

		if (this.getChoix() != null) {
			for (Integer i : this.choix.keySet()) {
				System.out.print("  ");
			}
			System.out.println("P" + this.id);
			for (Integer i : this.choix.keySet()) {
				System.out.print("P" + i + "  ");
			}
			System.out.println();
		} else {
			System.out.println("P" + this.getID() + " [ ]");
		}
	}

//GETTERS ET SETTERS
	
	/**
	 * Méthode permettant de récupérer l'identifiant du paragraphe.
	 * 
	 * @return L'identifiant du paragraphe.
	 */
	public Integer getID() {
		return this.id;
	}

	/**
	 * Méthode permettant de récupérer le texte du paragraphe.
	 * 
	 * @return Le texte du paragraphe
	 */
	public String getText() {
		return this.text;
	}

	/**
	 * Méthode permettant de récupérer la valeur de l'attribut alternate_choices du paragraphe.
	 * 
	 * @return Un booléen à <code>true</code> si le type de choix du paragraphe est alternate sinon <code>false</code>
	 */
	public boolean getAlternate_choices() {
		return this.alternate_choices;
	}

	/**
	 * Méthode permettant de récupérer la condition de choix du paragraphe.
	 * 
	 * @return La condition de choix du paragraohe.
	 */
	public String getChoiceText() {
		return this.choiceText;
	}

	/**
	 * Méthode permettant de récupérer les choix du paragraphe.
	 * 
	 * @return La liste des choix du paragraphes
	 */
	public HashMap<Integer, Para> getChoix() {
		return this.choix;
	}

	/**
	 * Méthode permettant de récupérer les mots/pouvoirs du paragraphe.
	 * 
	 * @return La liste des mots/pouvoirs d'un paragraphe.
	 */
	public ArrayList<String> getWords() {
		return this.words;
	}

	/**
	 * Méthode permettant de changer l'identifiant du paragraphe.
	 * 
	 * @param id
	 * 		Le nouveau identifiant du paragraphe.
	 */
	public void setID(Integer id) {
		this.id = id;
	}

	/**
	 * Méthode permettant de changer le texte du paragraphe.
	 * 
	 * @param text
	 * 		Le nouveau texte du paragraphe.
	 */
	public void setText(String text) {
		this.text = text;
	}

// Sharonn

	/**
	 * Méthode permettant de retirer un mot/pouvoir d'un paragraphe.
	 * 
	 * @param w
	 * 		Le mot/pouvoir à retirer.
	 */
	public void retirerWords(String w) {
		this.words.remove(w);
	}

	/**
	 * Méthode permettant de retirer tous les mots/pouvoirs d'un paragraphe.
	 */
	public void retirerTousLesWords() {
		this.words.clear();
	}

	/**
	 * Méthode permettant de récupérer la liste simple des paragraphes choix du paragraphe.
	 * 
	 * @return La liste simple des paragraphes choix du paragraphe.
	 */
	public ArrayList<Para> getChoicesList() {
		return this.choicesList;
	}
	
	/**
	 * Méthode permettant de récupérer la valeur de l'attribut trim_choices du paragraphe.
	 * 
	 * @return Un booléen à <code>true</code> si le type de choix du paragraphe est trim sinon <code>false</code>
	 */
	public boolean isTrim_choices() {
		return this.trim_choices;
	}

	/**
	 * Méthode permettant de changer la valeur de l'attribut alternate_choices du paragraphe.
	 * 
	 * @param aC
	 * 		La nouvelle valeur de l'attribut alternate_choices.
	 */
	public void setAlternate_choices(boolean aC) {
		this.alternate_choices = aC;
	}

	/**
	 * Méthode permettant de changer la valeur de l'attribut trim_choices du paragraphe.
	 * 
	 * @param tC
	 * 		La nouvelle valeur de l'attribut trim_choices.
	 */
	public void setTrim_choices(boolean tC) {
		this.trim_choices = tC;
	}

	/**
	 * Méthode permettant de récupérer la position X du paragraphe pour la disposition dans le graphe au niveau de l'affichage.
	 * 
	 * @return La position X du paragraphe.
	 */
	public int getPosX() {
		return this.posX;
	}

	/**
	 * Méthode permettant de récupérer la position Y du paragraphe pour la disposition dans le graphe au niveau de l'affichage.
	 * 
	 * @return La position Y du paragraphe.
	 */
	public int getPosY() {
		return this.posY;
	}

	/**
	 * Méthode permettant de changer la position X du paragraphe pour la disposition dans le graphe au niveau de l'affichage.
	 * 
	 * @param x
	 * 		La nouvelle position X du paragraphe.
	 */
	public void setPosX(int x) {
		this.posX = x;
	}

	/**
	 * Méthode permettant de changer la position Y du paragraphe pour la disposition dans le graphe au niveau de l'affichage.
	 * 
	 * @param y
	 * 		La nouvelle position Y du paragraphe.
	 */
	public void setPosY(int y) {
		this.posY = y;
	}

	// Fin Sharonn

}