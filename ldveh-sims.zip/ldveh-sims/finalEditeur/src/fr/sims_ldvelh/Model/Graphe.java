package fr.sims_ldvelh.Model;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList; // import the ArrayList class
import java.util.Random;

import org.json.simple.JSONArray; ///json-simple.jar/org...
import org.json.simple.JSONObject;

//import src.ressources.json_simple.jar.org.json.simple.JSONArray;

/**
 * La classe permet de créer un graphe et gère toutes les modifications à faire sur le graphe.<br>
 * 
 * Cette classe a pour attribut(s): 
 * <ul>
 * <li> Un ArrayList <b>all</b> de Para qui représente tous les paragraphes du graphe. </li>
 * </ul>
 * 
 * Cette classe a pour méthode(s): 
 * <ul>
 * <li> Un void <b>actionPerformed</b> qui représente les modifications à apporter en fonction des différentes actions possibles sur l'attribut tE.</li>
 * <li> Un Graphe <b>getGraph</b> d'Integer qui permet de retourner le graphe.</li>
 * <li> Un boolean <b>contain</b> qui vérifie si un paragraphe appartient déjà au graphe.</li>
 * <li> Un void <b>createGraph</b> qui met à jour l'affichage de sE.</li>
 * </ul>
 * 
 * Veuillez noter que le constructeur n'est pas cité.<br>
 * 
 * @author Ibrahima Sory Bah, Malick Sarr Gaye, Ahouefa Zounon, Steven Martin
 */
public class Graphe {

	/**
	 * Attribut représentant la liste des paragraphes constituants le graphe du livre.
	 */
	private ArrayList<Para> all;

	/**
	 * <b>Constructeur de la classe Graphe</b>
	 */
	public Graphe() {
		
		this.all = new ArrayList<Para>();
	}

	/**
	 * Méthode permettant de rechercher un paragraphe dans le graphe du livre.
	 * 
	 * @param p
	 * 		Le paragraphe à rechercher.
	 * @return Un Para <code>null</code> si le paragraphe a bien été retirer du graphe sinon le paragraphe i dans la liste du graphe.
	 */
	public Para find(Para p) {
		if (p == null) {
			return null;
		} else {
			for (Para i : all) {
				if (i.getID() == p.getID()) {
					return i;
				}
			}

			return null;
		}
	}

	/**
	 * Méthode permettant d'ajouter un paragraphe au graphe.
	 * 
	 * @param p
	 * 		Le paragraphe à ajouter au graphe.
	 * @return Un booléen étant à <code>true</code> si le paragraphe a bien été ajouté du graphe sinon à <code>false</code>.
	 */
	public boolean ajouterUnNoeud(Para p) {
		if (p != null) {
			if (this.all.contains(p)) {
				System.out.println(" ce paragraphe existe deja dans le Graphe !!");
			} else {
				if (this.all.add(p)) {
					return true;
				}

			}
		}
		return false;
	}

	/**
	 * Méthode permettant de retirer un paragraphe du graphe
	 * 
	 * @param p
	 * 		Le paragraphe à retirer du graphe.
	 * @return Un booléen étant à <code>true</code> si le paragraphe a bien été retiré du graphe sinon à <code>false</code>.
	 */
	public boolean retirerUnNoeud(Para p) {
		if (p != null) {
			if (this.all.contains(p)) {
				if (this.all.remove(p)) {
					return true;
				}

			} else {
				System.out.println(" ce paragraphe n'existe pas dans le Graphe !! impossible de le retirer");
			}
		}
		
		return false;			
	}

	/**
	 * Méthode qui décrit la liste des paragraphes du graphe.
	 */
	public void describe() {
		if (this.all == null) {
			System.out.println("la liste est vide");
		} else {
			for (Para i : this.all) {
				if (i.getChoix() == null || i.getChoix().isEmpty()) {
					System.out.println("P" + i.getID() + " [ ]");
				} else {
					i.afficherPara();
				}
			}
		}
	}

	/**
	 * Méthode qui retourne les paragraphes choix d'un paragraphe.
	 * 
	 * @param p
	 * 		Le paragraphe dont on doit retourner les paragraphes choix.
	 * @return La liste des choix du paragraphe p.
	 */
	public ArrayList<Para> paraQuiMeneAu(Para p) {
		ArrayList<Para> maliste = new ArrayList<Para>();
		if (p == null) {
			return null;
		} else {
			for (Para i : this.all) {
				// Print keys
				for (Para j : i.getChoix().values()) {
					if (j.getID() == p.getID()) {
						maliste.add(i);
					}
				}

			}
		}
		return maliste;
	}

	/**
	 * Méthode permettant de déssiner le graphe en mode console.
	 */
	public void desinerGraphe() {
		Para racine = this.all.get(0);
		System.out.println("P" + racine.getID());
		if (racine.getChoix() != null) {
			for (Para i : racine.getChoix().values()) {
				System.out.print("P" + i.getID() + "\t");
				// if (this.all.contains(i)) {
				// if (i.getChoix()!=null) {
				// for(Integer j:i.getChoix().keySet()){
				// System.out.print("P" + j+"\t" );
				// }
				// }
				// }
			}
			System.out.println();
		}
	}

	/**
	 * Méthode permettant de réorganiser aléatoirement le livre.
	 */
	public void reorganiserAleatoirementLeLivre() {
		if (!this.all.isEmpty() && this.all != null) {
			Random rand = new Random();
			int nombreDeChoix = rand.nextInt(10); /* en supposant que un para ne peut mener qu'a 10 autre au max */
			for (Para i : this.all) {
				i.retirerTousLesChoix();
				if (nombreDeChoix > 0) {
					for (int j = 0; j < nombreDeChoix; j++) {
						int choix = rand.nextInt(this.all.size());
						i.ajouterChoix(this.all.get(choix));
					}
				}
			}
		}
	}

	/**
	 * Méthode permettant de créer le livre en .JSON
	 */
	public void creerLivre() {
		if (!this.all.isEmpty() && this.all != null) {
			JSONArray listChoice = new JSONArray();
			JSONObject obj = new JSONObject();
			JSONObject para = new JSONObject();
			JSONObject paraInfo = new JSONObject();
			JSONObject paraFils = new JSONObject();
			for (Para i : this.all) {
				
				// listChoice.add(i.getID());
				if (i.getChoiceText().isEmpty()) {
					paraInfo.put("condition_de_choix ", " La condition de choix de ce para ");
				} else {
					paraInfo.put("condition_de_choix ", i.getChoiceText());
				}
				
				if (i.getAlternate_choices()) {
					paraInfo.put("nature_du_choix ", " Alternate Choice");
				}
				
				if (i.isTrim_choices()) {
					paraInfo.put("nature_du_choix ", " Trim Choice");
				}
				
				if (i.getText().isEmpty()) {
					paraInfo.put("texte", "Le texte de ce para ");
				} else {
					paraInfo.put("texte", i.getChoiceText());
				}
				
				/** les para qui mene au para en question **/
				for (Para j : this.paraQuiMeneAu(i)) {
					listChoice.add(j.getID());
					System.out.println(j.getID() + " mene au " + i.getID());
				}
				
				paraInfo.put("choices", listChoice);

				para.put(i.getID(), paraInfo);
				obj.put("section", para);
			}
			System.out.println("***********************************************");
			System.out.println("le fichier du livre contient actuellement:");
			System.out.println("***********************************************");
			System.out.println(obj.toString());
			try (FileWriter file = new FileWriter("myJSON.json")) {
				file.write(obj.toString());
				file.flush();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	// Sharonn

	/**
	 * Méthode générant la liste des paragraphes du graphe du livre.
	 * 
	 * @return La liste des paragraphes du graphe du livre.
	 */
	public ArrayList<Para> getAll() {
		return this.all;
	}

	/**
	 * Méthode permettant de changer la liste des paragraphes du graphe du livre.
	 * 
	 * @param all
	 * 		La nouvelle liste des paragraphes du graphe du livre.
	 */
	public void setAll(ArrayList<Para> all) {
		this.all = all;
	}

	// Fin Sharonn

}