package fr.sims_ldvelh.Model;

/**
 * @author Ibrahima Sory Bah, Malick Sarr Gaye, Ahouefa Zounon, Steven Martin
 */
public class Main_Model {

	public static void main(String[] args) {

		Para p1 = new Para(1, "bonjour");
		Para p2 = new Para(2, "bonne apres midi");
		Para p3 = new Para(3, "bonne soupee");
		Para p4 = new Para(4, "bonne soiree dansante");
		Para p5 = new Para(5, "bonne nuit ");
		Para p6 = null;
		/***
		 * ma fonction para qui mene au ne marche pas exaxtement jarrive pas a ordonner
		 * l'ordre d'ajout des elements dans les objets et JSONArray retour a la ligne
		 ***/
		p1.ajouterChoix(p2);
		p1.ajouterChoix(p3);
		p1.ajouterChoix(p5);
		p1.retirerChoix(p2);
		p1.setID(45);
		p1.setText("coucou");
		p1.setID(1);

		p3.ajouterChoix(p4);
		p3.ajouterChoix(p5);
		// paraQuiMeneAu

		p1.mettreUnchoiceText("le matin");
		p2.mettreUnchoiceText("de midi a 18h");
		p3.mettreUnchoiceText("aux environs de 16h");
		p4.mettreUnchoiceText("le matin");

		Graphe g = new Graphe();
		g.ajouterUnNoeud(p1);
		g.ajouterUnNoeud(p2);
		g.ajouterUnNoeud(p3);
		g.ajouterUnNoeud(p4);
		g.ajouterUnNoeud(p5);
		g.ajouterUnNoeud(p6);
		// System.out.println("****************************************");
		// System.out.println("****** NOTRE Graphe ACTUELEMENT ******");
		// System.out.println("****************************************");
		// // g.describe();
		// System.out.println("****************************************");

		// for (Para i:g.paraQuiMeneAu(p3) ) {
		// // System.out.println(" paraQuiMeneAu p3 == :"+i.getID());
		// }
		// g.desinerGraphe();

		g.reorganiserAleatoirementLeLivre();
		g.describe();
		g.creerLivre();

	}

}